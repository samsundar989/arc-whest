"""
ARC White-Box Estimation Challenge 2026 — submission estimator (v2.4).

v2.4 = v2.0's method, re-engineered for OPERATION COUNT. The method is unchanged;
only how many flopscope calls it takes to express it.

v2.0's graded-parity run billed 10.8% of its compute to residual wall time (64.8
ms/MLP against v1.1's 10.5), because residual tracks the number of operations and
the size of the temporaries they free (forum 18101), not FLOPs. A static audit put
v2.0 at ~1794 ops/MLP:

    closure                      832   (50%)
    slice + complement rebuild   416   (23%)
    Sobol point generation       120   ON 16 MB ARRAYS -- and identical every MLP
    weight-cast churn             64
    forward                       96   (irreducible)

Three changes, no change in math:
  * the unshifted Sobol net is built ONCE in setup(), which is off-budget, and
    cached — removing 120 large-temporary ops and 3.8e8 FLOPs from every predict()
  * dead indices come from the same comparison that produces the alive ones
    (one flatnonzero each) instead of a five-op bincount complement per layer
  * the rotation fold, the cast to float32 and the slicing are done in one pass in
    float32, instead of building a float64 list and casting twice
  * the forward pass is a single chunk (16384 x 256 float32 is ~17 MB, far inside
    the 4 GiB cap); v2.2 had already measured residual scaling with chunk count

Original v2.0 notes follow.

v1.1's Sobol RQMC sampler, plus the two Sprint-1 wins:
  * dead-neuron pruning   (a COST lever)
  * input rotation onto the network's own dominant directions (a VARIANCE lever)

Why these two, and nothing else
-------------------------------
Above the 0.1 score-multiplier floor the adjusted score simplifies to

    MSE * (C/B) = (V/N) * (N*c/B) = V*c/B

— per-sample variance times per-sample cost, with the sample count N cancelling
outright. So making a sample cheaper is worth exactly as much as making it
quieter, and choosing N is not a lever at all. Everything below attacks one of
those two factors; nothing attacks N.

1. Dead-neuron pruning (cost). Covariance propagation tells us each neuron's
   firing index alpha = mu_pre/sigma before we sample anything. Neurons with
   alpha <= -2.5 fire on well under 1% of inputs, and their contribution to the
   next layer is almost exactly their (closed-form) mean. flopscope prices matmul
   as (2K-1)*M*N from SHAPES ALONE, so sparsity earns nothing — we must hand it
   smaller DENSE matrices. We therefore drop those neurons from both sides of
   each matmul (output columns of W_k and the matching input rows of W_{k+1}),
   which makes the per-layer cost scale with the square of the surviving
   fraction, and add back exactly what was dropped as a constant offset
   sum_{i dead} W_{k+1}[i,:] * mu_i. Dead neurons are reported with their
   closed-form rectified-Gaussian mean, never with zero. Measured on the full
   100-MLP public split: 33.7% cheaper per sample for +2.6% MSE — a 1.43x score
   improvement on its own, with the pruned neurons' own MSE at 3.8e-9.

2. Input rotation (variance). For discontinuous integrands the RQMC convergence
   bonus over plain Monte Carlo is O(1/(4d-2)) — about 0.001 at d=256 — so a
   Sobol net can only ever buy us a constant factor, which is exactly what we
   measure (error ~ 1/N, alpha = 1.00). What DOES help is aligning the net's
   best-equidistributed coordinates with the directions the network actually
   responds to. Since x ~ N(0, I) is rotation-invariant, x = Qu is free for any
   orthogonal Q. We take Q from the leading eigenvectors of J J^T, where
   J = W1 diag(Phi_1) W2 diag(Phi_2) ... is the closure-linearised end-to-end
   map, and fold Q into the first weight matrix, so the per-sample cost is zero.
   Worth a further 1.12x.

Stacked: 1.61x over v1.1 on the full 100-MLP public split (V*c/B 4.489e-7 ->
2.787e-7). A stratified radius on an extra Sobol coordinate was also measured
and is neutral (+/-0.5%), so it is not included.

v2.4.1 changes nothing about the method and is not expected to change the score.
It fixes a reproducibility defect: J J^T is numerically rank ~68, so the tail of
its eigenvector matrix is arbitrary, and a relative weight perturbation as small
as 1e-15 was enough to hand us a completely different rotation and therefore a
completely different realised point set. Two harnesses running this identical
file disagreed by 18% in mean MSE over the same 100 MLPs for exactly that reason.
The rotation is now built from the well-conditioned leading directions only, with
canonical column signs and a deterministic QR completion.

Rows other than the last carry covariance propagation's means rather than
sampled ones (only the final layer is scored, and this avoids a scatter); row 1
keeps its exact closed form.

Grader compliance
-----------------
* Only `flopscope`, `flopscope.numpy`, `whestbench` and the Python stdlib.
* All randomness derives from `fnp.random.default_rng(mlp.seed)`; reruns on the
  same MLP are bit-identical.
* No in-place mutation of grader arrays; no flopscope introspection inside
  predict() (`budget_summary_dict()` is O(op-history) and inflates residual wall
  time ~157x — forum 18092). N is sized from an analytic cost model that ignores
  pruning, so the true spend is always BELOW the estimate, never above.
"""

import base64
import zlib

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import MLP, BaseEstimator

# --- operating point ------------------------------------------------------
# The score is flat in N above the floor, so N only has to be large enough to
# stay clear of it. This target is applied to the UNPRUNED cost, so the actual
# C/B lands near 0.19 and can never overrun the budget.
_TARGET_CB = 0.30
_MAX_CB = 0.34

_MIN_LOG2_N = 9
_MAX_LOG2_N = 20
_CHUNK = 16384

# Prune neurons whose closure firing index falls at or below this. Measured
# optimum on the full 100-MLP split; -3.0 gives 1.38x and -2.0 only 1.23x
# (the MSE penalty explodes below -2.5).
_PRUNE_TAU = -2.5

# How many eigenvectors of J J^T are trusted as *directions*.
#
# J J^T is numerically rank-deficient: its relative spectrum falls to 1e-6 by
# index 32, 6e-12 by index 64 and 4e-17 by index 96, so everything past ~68 is
# below float64 noise and LAPACK returns an arbitrary orthogonal basis for it.
# Measured consequence: perturbing the weights by a RELATIVE 1e-15 — far less
# than the difference between two evaluation harnesses — changes the raw
# eigenvector matrix by 0.81 in max column distance, i.e. a completely different
# rotation, and therefore a completely different realised point set. Fixing
# eigenvector signs does not help (measured: same 0.81), because the ambiguity is
# a rotation inside near-degenerate subspaces, not a sign.
#
# Keeping only the well-conditioned leading directions and completing the basis
# with a Householder QR makes the rotation reproducible: at rank 32 the same
# 1e-15 perturbation moves it by 2.7e-11.
_BASIS_RANK = 32

# --- Strassen-Winograd carrier --------------------------------------------
# flopscope bills a matmul as (2K-1)*M*N from SHAPES ALONE, so a fast matrix
# multiplication reduces the counted bill exactly. One Strassen level replaces
# eight (m/2,k/2)@(k/2,n/2) products with seven.
#
# Measured on real flopscope 0.10.0 over 6 canonical mints (LOG 2026-08-19):
# counted 1.1500x, effective 1.1155x at the grader's residual price of 7.0 us/op
# (calibrated from graded 327743: 1,416 ops, 9.845 ms). BREAK-EVEN is 55.5 us/op
# -- an 8x margin, which is what makes this safe against the 44% spread GOTCHAS
# records for the candidate/control residual ratio across local harnesses.
#
# Depth 1 only. Depth 2 improves the counted bill to 1.267x but costs ~7x the
# operations; the two cancel at our residual price, and depth 1 is the more
# stable of the two in float32.
#
# The chain is BLOCK-RESIDENT: layer l's four output quadrants ARE layer l+1's
# four input quadrants, so the 32-layer chain never concatenates -- concatenate
# is billed at 1/element and costs ~2.7x that again in residual. Only the final
# column mean is reassembled.
#
# Exact in exact arithmetic; float32 reorders the summation and moves the
# prediction by 2.19e-7 relative, against a ~0.23% relative RMS error at the
# scored layer, i.e. ~10,000x below our own error.
_STRASSEN = True

_SOBOL_BITS = 30
_SOBOL_DIM = 256
_SOBOL_B64 = (
    "eNrse39YU2X//3tjjDHGGDBg/D7AgPF7wIABYxwTC81smRaZ1TLrITObZkZqdUtmZFrzR0VmtcxHydQwf0RpPkclJTNbpkZmOn9U"
    "ZGarqEit5/s67nhdu7jqeT6fv7+fq+vunN3nfb/fr9fr/brPzrkmRMTR/43/G/83/n8dOgxz0NAFzen+YgTH/dXR/Dc5/y7W/Df5"
    "zX+T7z/hNf8HjP+Nl+5vcOr+A76/0+W/afU/0e3vrv9v8v632P9J3v/E8b/1939SU/dfvPeffPA/7Y/5b/r7nzQw/y/1/0/c/5vP"
    "zP8DX+r+l737b/vw8lBhmDAM0rlKOjcFDat0/KtYVdC8VRqGoHjVoDzB161/s1Y1aL31L2INg+Ktg7Ab/gLf4JrBa4N5GoKGKQiL"
    "4S/yGQbVDcZmHYTBOij3YD1Mf8PH+hf4g7EO5vR3uhoG5TEMujZY78FaqP5CM8Nf5DEM4m4a5InB+gzmqPqbHhsG1bf+BX7rX6yx"
    "/kW8aVBd1V/kVQ3iMbg3g3uh+oteGAb5RfUXe2nw/rAO8sNg/n+1VwZrq/oL3/xVbxQYNgwjhh6jEEODYZE+X55TSPN6KdYmxdik"
    "cTnOIg1jUI7BOS9f0wTlTAnCcDlnoTRsUpxCirmcLxhXShDeyzWDzy/nSQnCYgm6ppc+K4KOl/MWBuEKrqkZVMsoXdMHYbYFaawJ"
    "ymkMumYZpIMt6NwSpJtGWpcirbusd8ogTRVBc8Gxg3OkBNUwDsphCcKg+AvtUoLq2ILOLYP6GeyPYL2NQXlsQf0J7kHhIB76oFqX"
    "8WqCdC4cpGmwZwf3TBOUL9jHlkGeC/aUMUhLxSAtB+tiHMShcFA9fRBuW1AvbUHc9EH9DJ63BfXJGFRbMchvwd7QBOkerIscIxOj"
    "BsMujTKMeGlejZEjxcVL17UY+RiV0nmSFFMsnWul+BgpRrymlOaSpPyXY9XS+eVryiAc8dL6fGlNThCWNGnES+szpdh4iYtSmrvM"
    "JUZaa5fiL/PMD+JaLMXZJVzyoNxyaWilupXSZ7U0VxmEpViaixmEN0eKj5Fiy4JiioOwq4PiYoJ42yWN8oP0jJFylwXpdjkmUzq/"
    "zCFeipUH1cgMqisPWhcvra2U1pdJnMqkURmEOSlIL7X0WR6kX42EP9gP+RKWy9oppfP4IE9WBvVPGfT5sk/KBnmuMki3sqA+q4P8"
    "FSMda6RxWb/L/U+TjjnS9WAM8UFeyg/qY2VQn9WD+iMf5MHL+6ZSwnG5P5f1UAbpc7n3l/fM5X2qHeTdnKAe5Ei5L+8frTQu77Gc"
    "IE3EcxlGOUYCRipGFUY4RrZ0rJDOkzEKMLIwSjHipGMoRiJGHUaUNLKkuSxpPg8jEiNWGqlS3Vopf4YUVyfVj5SuRUg1xWO6dIyT"
    "4kVsudK8GBONUR90LpOuR0mfxZpFUv3LOEuk+mFSzTBpfaSUK1bKXyHNVUvXkyWsIdJchIS3VKoRKs1FShgygtZlScdoaW1VkLah"
    "ktah0rowCeNlPeql+WgJ12XNUiU9SqSc1dKacglPtXQtTqqXIGHNk85zJS6p0nm9hLlaOr/si1jpGB3U+zoJ5+U+yIL6nCjliJNw"
    "1ElzYVKdPKluqYQjWhp1Uv0QKSZL4iIL4homrYuS+pMq5Q4NwpEdhD1LqpEozV3GFRrU18u4IqWeJEp9DA2qc1n/Aun6ZU3zJMwR"
    "Uq1sadQF+TJEOg+X9KkN6n2IpGGUlDc5SMNg3PVS3OV9J5PwhksaVUvnCVKuKgnjZT/USjgjAzUZDgz3EQbMDO8JDPcghniGtQzP"
    "CQz3FYb7DgNvBj4M7w5Mh4F7B4MODPwYcjFwYOVSbLq0rkLKkybNi7XAgeG5g4EfU0nzSimPQcptkHLkBOHiMMCV4V7GCiU84MLM"
    "GHjGYTFSDrEuuDPcA1mEVD9dihProk+sSqoPfZldWh9cQynVqJPy1khz1VKcmM8irQuTzvG8xRKlfOLnDKm2WMMo4c6XMMVK+XTS"
    "tQipbrw0FyPVEDUNkfoQItWSSVyyJC7hUqz4uUyqnyFhEPMVSZ+Lpb6WSVjEUS9xw3cBK5HO7RLPMilvsdQ3hcRPJelUKuWLlXIl"
    "SDG1EsYiqQepUkya5Id8KX+dtCZM8lSBFK+R8CqkazaJR4gUJ5fitFKOOAlntjSfJGkhH4Q5QYotkjAqJc5qSfN66Vwtcc+Xzi/7"
    "wiqts0rXqyW9UiS/xkufOSlvibQvSqWRHJTXJmGyS2ujpc9WyTMRUkyFpGW+tBeSJU6FEsdsqZ5KiomR9OYkX3CSv+Klo1HiFC7F"
    "QSsevRXAnQdGAdd57CsBuARg4YGDBz8B6wXUELBWQH8EUyCOR58E6MsDlwCf8NCR1wfW8NjXPHrEAyNfIcVDewE9E8Sa2VI+1BbQ"
    "ewHxAvalAM14xPDQhQcOXh7AIcBDfLmUB7UEaCagh7yIszDw+VIdYOILpHUyCR94CuiXIAvgEuvwWCvEBWqIuS9hsgfwXsIkcoav"
    "BPRBAG7eElgvlEvX8yV88CWPXvCoI2glHNCDT5PwIQ9vDMQJ6IdgDsTxyMvDI8JlvcQeoCdCWkD7Sz2xB/gJoq5qSS9RC3hAEDVP"
    "DegkJEhaayXuuYG6l67LA/iEJKl3OikH/MRHSZ/LA3M8vlMEi7RWjM+QYkskfqJWMZIvTBKmOEnX3IB/xPWiZpewlwZyiNzEfl/S"
    "KUnSP1TS1hDgzIt6Vks1xT6KMQkB313qe6HUQ1EXc6A2Xyl5MC3A9VINo5RHGchxSavwwOdLWMR57ENeIc1FS3XEXpRKfhX5l0ka"
    "JUr1YgM9F316qedyiV+55FtR2yzJt6KmeYH+8rgn8HnSnF3iq5bW2CU9kgIYRUx8jlSnKhB7qX6CpGFEwM+X9ku5pI1Myify5gJ7"
    "7JIGsoC3hJDAuKRnsaRFnuS7DOlnQPyPAwYOenrAnYPnPMDugaYcPOUDNx/6zKEvPuRyom8e3JudyOMDZye4+aC5E3icwM6VBa45"
    "KwLXPajhA25PZGD4oInHFjjngMGJWk5xDfrIIQcn5gBnDv70wFeeSgkPtPekB87FfD5xDfD4kN8Jfj5xHpr6cJ/2II8PeZziZ3By"
    "FgWue7BvnNCL0wd4e6CV0xTg4MQ6J3TzAZsvSuIvXsf9iIPmnELSAb7h0CcP9oIPvuCwf30iD2jlhP+d0NhjDejok0n8xJzQwyPm"
    "gcc8WOcRNQceLj2AWTx3ijlx9Omkz8DNiZhyA5w5kQ967wF+p6gB9hFnCeTyAZ8H8U6xfxWBGpzYGzEnes8Bu88a4CJy9nCB605w"
    "9YEDJ2pYGeDnCwvoLuYWPztFnKWB3lzSF/Wc6QFNOXjTUxXgL+a/xB/71Yd++RKkvsDLHuw1T05AA6d4DTpw5ZLHRO3iAz7wJEj4"
    "4XePiBu+8IgYEO+MDmh8SR9tQCNPbcC3zoxA/0TelzyGz76cQF9FLj6TlFesDf186ZKPL3s3POA/8bqohZiLwzUOGjuB06cM6M6p"
    "JcyxAR9zwOlDPIcecWKvNQEtxLhL9YDfJ+YvlLQV66KWU9TELK0V+4p7is8i6akL9NyJnjnhQU9eYB0nerFY0j4kgFH0lzgv5hP1"
    "95gkXAkBjT3om68+4F9xf3q0EhaN9JMgMJhRywFMfnDRwQt+4HVjTgddXdDOhZ45gM8hziOHGbk7sT900EOHmi7UceHcBS5mYPKi"
    "j27kd8BbOuByw2udqOOFHl70zIWeOJDfL9bCGgd4OsQjcJuBtRO6dwKjC1wc9kC8H9p5wdsP3b3g60U+P/J1QjM3iOiA3QxsOnhT"
    "h/7r0Fsd+qZDXjc0c4OLWxnA5RbxiXzEnKlSPvjFgXmvMVBHvOYAbge094r40gP6XNILMZ2I94v6wR8uWQCLPyzAyQzNOq2SHrgH"
    "mpMD61zwgks81gXWuMQcwGoGRz/OzdCrM0WKEzUV9QN2B3g50Ec3POW2SnXA2yxySA1oLGrognfNhQEdveiVA2s7Ud+L3pqhqQ6a"
    "m7MljojTQWsd9HTDG2ZoaMb9w2EOfL6kZ5rEDWvMsYGfj72477gQ5wZfsyXQK1EbL2Lc9kA/xPydiOtUSNrVSV7DsROY/eIaaOIH"
    "BrMiUMeB7wMv8OvQazfOdaKG8Jkb6/zg44LPO6GnX9RbrGGVPIccXqwxi/0qCmAVa4q+dCOfH/3rhD6d0KMzUtICurhEr9gCvRK5"
    "OmICernQc51S6jViXFkB/7txvVPkopd6C90duL84gKdTvIZ4d0JAL3dSIL8b+d3oW2d0gIu3OOBrsSdirzpxvRO8XKJWor8UAT1d"
    "yOnFvBt8dMBsrg30qVP0CjD44wN7z43hgHbm0gA+N3B6RS7GgD/86QFvmKsCGop7uDM3oI/o10s/H2KPtSN/C3I24dwA3G3wlwqx"
    "bajXBj/2IU8HODdDWys804jPzajVAQ5dqKNCfBPi+5CjD9qpMDrAswc1W4DRiuarwGkAHjeAay94tkGjHhytmO/BXBf0NMDfbdCm"
    "GXgbxfzYjwZgawLQPtTtQWwTsPfgeh84dyC+CabswehCnErMLw5o1wZ/tSNvGzD1oE89uO/1Yn0jOPVAs0bk6wCuZujaR4H8A4hp"
    "hn4t4NUMbH3oWQfm+8Q4nPdBSxO4m2oDuFvQzy7wNEF7E+K7oJEV+AaAvQ+6dABnE9Y01gW0bYT2bcDWjntQG7C3o7dton7gbECs"
    "Cn1TQW8V8qrSA/Nt8E4bNOxBX3ow14jrjeDUiPme4kAvOkTdcd6B9c3A1gG+JvS3A/ePZnA1oV4f8JqKA5zEnjfDp83AY8L3SDt4"
    "W6GLFbyb0GMD1rcDdxdqDiB3C/QdQL0BYDeAaxf60gSuLeDVDvwD2Pdd2Dct0LtJH+hzL3L3ov9dqG1NCWh7aQ54m9DrAeRpF3so"
    "1oZfTMDVAy17UbsFOXu4QG97gbNH9Bb80oJetIk/Y6O3XeIa5G2C1l3wX0dRQIMm7J8BcOpAjjbg6xExlwc0UKGPvchhRe5e0SPg"
    "OoA8bcDbBE4DuDdYwdcKDU3KgLebRR2gSx+0bBf7jPuFCRx7gbsPeduRpyk/kEOs35UTwGfCujZg7xJ7qArk78K9SCXWAM9G5GkX"
    "PQXsBniwSdQQNUw49sQF+Ih+NckCuUUfirVEDD2obxDzgc8A/NqMGl3wT5u4N4G7V5wXvS96AfFt0F2FfC3w6EBsoG9dadJPhejR"
    "RNTbBN0Kca5BzW4cFVjfAM26gWk6fLUUNZcDbwOwNKDeWvTjInS+CL4a6DQe89OhyVFoMBE9mYvebAO2FGhngxYHwWMf8GwDbyPy"
    "LEedtejvQWC9iHo2xBrRj4tiHeyNBWIu1F8LjEeh7xjkPIijDfp0Q78G5BsJHqdRvxt+Gg+PLEDMUmiwALgawgNx3cDVbwpwuAgt"
    "VgJLP+Img8MY9GUkNFUglwbxCuRYDr7LMX8R+pxGrZXwqwWa2nBtMrCthT+2wT+TMb8JPZiNue6yAG8F8OuBWwFeS+HtBVg3GcfZ"
    "0N8CLtOh8UERO2o0QJcx4mfovAA8lmPokVuDfaiANgsQMxd7eCT02Qesp4HPiByF8NZkaGsU+wXcE0WNgXM8etAPLNvQ1IOI16Pf"
    "KejrbPjLgjUpwNKPdcuBbTbityHvbMxZUgK9sMDLm6DNUcQfFPuJ+rPBcxv6vA0xB6HHGMRvA9fxwDwd8wfhpUJRI/ToLO4PE3MD"
    "PzOLfioEv5W4thb3OGNFoB8N6FMD7hsLRM8glwbBCnxWiNrhmgKY54LXXKyfC0/MBZa5oueAqxv+7q6WcqB/3ajVDa0awLkBNRqg"
    "XTf210rgPo34lch9Gmsnom8rodFE9MYIXkZoMxHHiYgz4tpp8TriVor7ADhOI9dpYwDzafjwNPCtBN+l4L0J+MagzibUnQ5PHQS/"
    "g4ix5AU8ogdnCzCOAX5LRECfgzj2i70XPQEN+6FPP/aBBXWmw0P9OI4BtzHhgf4vxfEg8G8Cz+noS7/oC2Ccjvp69Gyp6Bv42BIS"
    "8F8/ah0Erk2oYwHHTZi3IH5pUSCuX/QS6mmAazZ0v5gR2Ae2XOmnVuRLQp/lwLYCe/MtzL+MXs6HfvmInwLcExA/H1zkuC6HHpnA"
    "OAn11sBrNah3BvMvQ79HUH8VYk+iP7+iL9NwVEPv0dDzT+hzBpp9DTyHET8T+fZDv6dxngYNzsF/J4HtGPbLfsTfBVy3It9o9CkJ"
    "2LZjPAIfq5FzHPyYhOtngG8x8kyBVlcg/07UHoH9fxixZ5D7DO4XW5B/N7DuR8+3o/4MrD2DvGcQtx3YtiNfq5gHPUgqD9Q7Au7b"
    "kX8GfLEen0eD45W4J7wL7FOQ7zy03Iu5NJzPR3/s6NsjqPcc6mvRDzXq7IQndmJNJXq/BvhGoMYRCJ6Jox2eyRT1Qv9mANdo5DuG"
    "czn8LocWT0O7K6DzlVh3DvXXIMc4ePBlaDMNeY9h/TjUjocP7eC9BnwmQJtzGKuAcZLICdyVWLcbxz/B9Ri4vYX7RQx6+xzW3wov"
    "xUPnNPgkCfi3gM8M3LtiwKMG8b+KeBF/BHWS4J+vEZOJ86fhTTk+a6HPFeBeBgwH4IPFwD0OvGOgdRlwPgcsaeC1HXjeBfZV4s/Q"
    "om+AYy9yqxGvjA9gVGKuFddbUXs3YnZi7U704Epg2w0dVuF8Ajx6F7h8jRoTEDMBvCeA90nMncS9KBN9XQV8v4LHYWi7WMSCXszQ"
    "BzBOw37+FdotRswM4KtErRuw338Vr6FeWXTg/Ab0aAtw3QCeo3MDPT0Mrc5gry6DPsX4viiOCOhfLGqEa0nQcz80z4efjsF7M4FV"
    "ixpr4OdliDkjekf0LfTOx/pjwDoJfP9EvlHiHkONM5gfAaxJ0LQGur+LnGrUnAme58HxPHJMAeZz8MStyHsO2EYgz17k/RP67UfN"
    "mcD+CDw0BdjPYF8cE/cQ/DUfa7SYnwncf6KWHXn/1Eg//2NtLvZ4CLT+ETp8gH1wAv0ahpg45NsKzTYjZg/4hCNHCDBORd03gekP"
    "jH/h88PQeTW4b8bxB+R6D9c3As9jWP8jdL0OXCIRdx16cBvOH0LtXRhPwANPAOcnWDcL16OQ7xb09Gf4KQvrErD+eeRJBv7f4IHX"
    "cW0zsMWiVirw1KHWl4h5EfM3QZ9UeOUPkDqFvDLMDcf+vQB9b0eOWfB0Ajg9g7lvoMGr4LUDYzVi3weGqxH3EjQoh2bfwjuHcK0W"
    "dd6DzutQ+yvE3QL8O1B3DjjMwrWIkkD9j3D9D2D8AN5bhPNQ4N+I+Tys+QKaJuK8DvFb0YvfgON17PUq8EhG726CV3+EXieAaQlq"
    "PgNPDkOfc/H5e9SrgxcroPuHwDcEPI4j5iFw+BS1x+L4KLzwLHRYhDw3or8vgeNGcP9IxIcc6+CnBLFn0CUdeW4Bt8eg92s4nkKv"
    "M+CVT4H738D1IvBMxXE1sN2BfbsO3v4Qe2sYarwADtU4vxp6LASWMNRZh5qfwNNvA0sivLwEPX0K+skwhkKHYchbBM73ANfzuGf8"
    "Dh+9ZAxweww6hgJ/CPg+gfvEMOR6HzleRe1vcDwFjb5BnlOI/xHYf0ZMOXTZgHxvo9e/QYfPcD0WPtkIXIuA+zfocxs8MAt9/BYa"
    "XI2cz4ieQ+2PsY/eRF8uIMctwDsLGtyHvt8CjC9gz4ZDpx+QMwqx9yH2HdQvwfqHUO9u9PB5eHMz9PoUWldAj3LUeQAalANrNGqM"
    "BY6fodcwYBkCfHuQOww9CEXcHPCdg+tfoXYGdMlGrRPQajXuYyeQazhwR2BtAbS4AG/dJGoFPh+jN/WIfQ+6/Ru57gPfe1D/HsTV"
    "o3+puF99DqzD0d9bUPcHnD8FTV9Cvlr4JhyY84BvITSMxJrfsf4h4DmO66/kBX7aXZNPrNZAjHHEmjA2FxGLTiOG9w0230zshJ6Y"
    "PJPYasQ8XkxMFk+sr4bYpBBi+Yg5gs8+HEnMIcdAXmc45sqI9WDdAOaaIojhHZnhPsjuwvUZmDtiJKbUEauMJbZFiSPix8UhD2r8"
    "bCH2LtYUIc/odGKrwoh9iDr9wIfvBbZUQ+w55CrFWJJB7MYUrC0glqEgZsA6cyixF23E6kuJ6UqIqSuRJ5vYQuT6MJfYPagzFLET"
    "kXMdMJ4Fl3cQe2M5sbXge00VsTeA7SNc9yCfoZrYI+BorSNmQ56PUWsn5l6xEvMDgwUY8oDtDqy/LYpYCrj8jthRJmLvgbcSeA7k"
    "QDfwGImYCxjrkHcZaucA31vRxF4A52sxdmJtJvTpTya2CWuiUzHQo++A6SR0x/2fhUK7FDV4Il8yuN2F+Y+QZ5EdeJDXgfgVWmJ4"
    "12Rjs4hdARxP4HoGrm+H1jx60It+vQsub0PPOtS5Db3OANYn0f93wek9eGMAOnegzu2o/TTifsTnUxXEuqENgzZLE4kNA94wrL8Z"
    "mGahD1fhegRq3os6HfDRL8CoA8YNGHb0dg10ikXdvdAMz/ksLBI5Eojhnsy+Tg78HF+JuM34/CmwTAeHq/E5H+vroVMz8m7D+rOo"
    "l4jjk8D9MfR9GBheQX+N6GUmuCmA93HEXIn5BmhyCOvjML8FHJ5Fvkrkvx75poFDAfSZhfMa9O53aLcVMX8A03p44hiOo9DLc7Xo"
    "F8Y9WDcFOWvh2/Po/+vo1YfgbcC6m6DvXaJfUcuXBM2BVQaf7UGfecT8gviD0HI65jcirhQ+2AA96qGXFesTgW8SztWoeRT478Oa"
    "W4EpET2fieMU4CpCfDd4DYV2eFZkYaiJdxZ2EjxOYO4ANIvDdTPWRsPLlfisQf02XHsPOlVDn/2odY0i8PM/7vs84vkdZhKKdSSc"
    "yyQhMYP4xcXED68m/mE1CSERJLygIOGjWuLlcSQ8mEr82jQS8BwrnI0g3qUigVJI4JGHTybBK8eIJmFbDPHjCxBTQrwRx+tCiX/F"
    "TkJ4OQlLOBIKrMQviUSNQuITMkjYinrVFcTj+Yj3JRO/MIn4dgMJ04BxbxjxLZj/PpP4BxDXHEVCBGrujCI+u56EbgsJWVrkrST+"
    "U+TaAQzlxSQ8VkY8ni95WzwJVwL7Q5ivTSThN2DbjtoZ+cQ/W0P821h/N/BMzCL+DWB8H+sKS4nfkkc802NNJQlz7cRvzSJhnYYE"
    "J/Tz4hzPWEIDYndZSZhSQ8J9ucTHgCfuh/yPuLYU9dqKSPgVa5chvz+GhONY78sm4VA48f3gc0sVCUOg57uodQLHRNT6IBJ8EokP"
    "A8dJyDM2h4QqXF+WS0IoOOIZgL8GWLPRpweRP19O/FQT8R8Ccwe0H1tA/AKMz6BBZhr0g/5+cFwB7bKB4w7otwk9PwKdi6CbyXqJ"
    "D497lvB1CQlRwJucgJ5A8wFoPBJ8DiP+EGLhceFD4LwTue4E3zDg9ENzn5b4lZibD537q0lICCdhOGqm4Pw+6HAb+mkpIv4e8LsX"
    "Pd+FuHnI50RMNPAtRp4m4DgLHW9F3lG14IVezS0FB+DA/Y//rYyEg9ANWgkfxBJ/H2qsCyMhqYr4l+BPvHfz5goSwpBjGPqbi95M"
    "gHc+h2bbUPtb6PMttHoIcWfB9SXkOBBKwqfw0BxoHIa+rIK2eK4T4DEe3w1CE3r2rA36Q5Mfwc9tI16mBB/U/gPX3kPOhXXET4JP"
    "+5HjgTjiY0VPoA7ujUIucK/GmAzNZ8H7r6iIX28BV+jbDB0ysWdWoO4c7KMHoOGvWP8t9tZN2E+jgO919KUataegryPB6Rvw5+CZ"
    "OcAYAjy6HOJvwN7FPhauhRYD8O9x7NeZ8OdMcR9D78bUwD8nwHumcCP2tyxc+itg/MfVkC9LRb5XVfgUQxzeM7knleRZayPP03Jy"
    "PhZFvrnJ5Lk9lHwsjTx9SeS7u4KcI0qICzGRr01BPoonnzOGnJ5a8qiKiWs0EvdTEnnWFJFnPtYdtpDzjJl886qJW0/kPKAlT6OC"
    "uCY1OZ355PTlIIedOE8hcX3A1FNL3DEdcdOyiLtCS9wNucRVmpGzlDxL88kTH0mexBjyyFDjnTzyeFTkiagnzw49cQ/koG49+dYn"
    "Enc8mXxzEsiHPcJxOvItE3+atZGvIpU8H6L2QAj59leQz4jYzwzkXFhOvmYrOfOqybevipyrU8hzUyk5h4PTJxryDNSQ5yJyY3/5"
    "ao3kPIE1D1cQd28Ucb/XkPOrRHIuyydOacN5JTmvRu3PoOe7meQZGUueo6Hk/K6YfIdiMach3wvQ4ucw8uF7gPsMnCxa8tUD510y"
    "8unBJQRax6PWiAxyLkLMDuANyyUn3p2cd8aSbxw0vzUZtXOIEzmvjSPPdejhnSXkuwa8nkeP7OD7GmLejSTuIjSdAVxbMF8BTXYX"
    "kudP8NiOHkeUE2fMIqfbSpwWusmB6xBqPYhe3KED1wzytUeT5yXo/Sb0mJZGzi+iiVtoJ99uHXlewPwn5ehrJvneTSBuVAR5JoH/"
    "S+jzdHCYj5joKvL8BI+8gp6+WoX6wPkTfLcX+CcVk2cX8LUoyKnB3N3h5GyuIycPfQ9g3S/wRlQc+dQZxPE4fqZAPzjy4L2MK0Lt"
    "ZYh9F/4qQP7QEPKIvr4OPVwCze6OI86EXmrg+ynwcEU2eWJTiDsMLbCvfMmJ5BsG/+C5xnlARlwbPNkWTp4s+CGmHp7UkvMY9sQ7"
    "2eR7EVgI/BaUkPMUOLVGBn7KPwjPXCyD9/OIO48cE6CZArndqH8AsYXQI1lPvm5o0gpt3THkw7OO71cVOb3QeVcd9gp6pcJYAn9W"
    "acj5Dfx+CvtiGXicAYYX0LcNdvL8CPzD0oh7XE2eccD4Shj8DA3K0rEH4cmJWDs+m7hHc8lngkbF6EFxLDnnJ5GzJhPryqW/CMZ/"
    "5gTyXqcn10+FmEsk84k88l4ZQ7rRadS5V0n+9zXk2ldH/hdzSbcrkRzTI8nxZgm5z8nJIdOQe7+WOimLvK4QDDW5J0aRd0w+OXZh"
    "Hu855j/s5M1D/HXR5L02hXRF0eT/OIv8k5WkM1aR2ZFIXreO3BRLZlc9mY+mkXlfBJlvTCbdE2Vk3oPz12ykq7OS+SEFuR4AHjxb"
    "esPCyZseTa5HKsm/I5u8rRryv60gx7kScvVHkXlSCrm2lJJ5lJVcVwHrh+HUeYue3PokcqcUk66/nlyP1ZCrT0H+u+PJhWcw89BU"
    "6nwxndwK8PknNCnLIQc85RhQk3dqAnW+FEedi9Kps6qWdHuKyXUwn3TZyDlVQe48OzneyKDOXfXUKcd8P7j6M3E9g3R4fjLPiCL/"
    "mjTyjzaT/3ec20Ooc3c9OTjwwv3d8WcFmXcbyZ+FXLdYSecKJzP2uvsrA5nz6sjVo6NOp4pc83LJvzOL3L9XkmtXLXkXFJHjy3hy"
    "P1BB7nb08g1g/LcSR2g6O578M7IxMsgVnUid+7LJ9Qq4H4KG9wPnyQxy8JVkvoCeMyN1Hq8hb7SNHHj20j0J7FebyFwDLkdiybE4"
    "ijqnqcg8wUKdW6C3I5wceP7q/DiD3PcayPFTKHnhHddK6PKlitwdmdSZDt0PwUdq9HF4KLnRc3NTDnkXc+R9Gx5cDQ6p6ONiaF6B"
    "XmXCP/PgtbtSyJ2KuJ4IcmVAi4vQ54sk8j6GMamSOlfEILeW/PhO6PwRvZrDkeNlNfn98eRdlk46ln0Jq/vmLHJNUpP5fTuZD8N3"
    "s5CnIJZcvwM/nondanjlF9QJ0ZCXA46GQvK+VE3ecmiH51D31EJyj4CeMWHk9ZpJl24nVzryt4L7ijj4XUe6IehvD5FD7M+YdDK/"
    "nkf+InhnBjRmNupMxL45W0W6/Tpy3Gcj76vV5L4yihxTxH+eAM3Gw1/rTNT5qo7MJ2vJ8SA8HZ5Irskx5P4Mvn/OTp3rEb8GPYqH"
    "Bycjr6qcHCfh9e4ictuA9apQ8o/JIocNa29MQ6+AdyT23B8h5DoK7800kOuJdHKI/xzkNnigWy799bCJDO1Z1HbeTs2f28nAIqkj"
    "upKai0pJ9bqduk5byHA2gUyrtNSrTCPViULq64uhgT4jdc2JpQFZDPWq86iLpVJzn4asjdmkOplHjfZ0auqw4im4mNrLqqntT6w9"
    "k0+mNCW14ztXpVKTako9GbYkU18P6vfWUgvTksqUSKZzyLE7hNoiQ6lrkom6tsVS2y8y6sjXUJc7n7r0EdQ+w0ZdS0rItDiVDFo1"
    "maw5ZHUiJ94bVJySVG21pDIoSNVsIlVOJanWZ5DqayOptieQSp6IkUFtE/XU9pGN2hQR1Had+NN8DrUZs6ltbAq1PVtBbS+GUts5"
    "XGsFPn8dmUpLqaNXTh3jY6nv3hzqe62amn+3UPOuaDL9XEymz8zUfH0cdMghk0ZGzT/EUd+vudR8nYY6vOlk2ldOprdqqG99HjUf"
    "yaGORyqo+e4S6ktWUPOUXOqYxtHAmQyypqVTz0Pl1KTWUg+eu1o+T6CujfXUuDaarF7k35VK7c1a6voB14vl1DMyjww5kdSYU0sD"
    "v1dRz02F1LixhppfkVHvVWHUdJyory2deovDyZSXTwNzoO2UUmpenEVdnxaj11YaaALO/clkfdZEHUeqqGW4mdr3ZpPhvhhqviGO"
    "DFOM1L4wnlRrVNSrryKTKYyaw/NooDCeWm6Pob5PVNRjSqCOP5TU4q2ijrVh1BONnM+lkOr+KLKGR1JXAXDrOerRxFHjsgwamJZE"
    "vT8nUeMiPZkWWsl6azR1fQasuxKoD/cmw2mi5vRcUlWi1zclUMtSLbXxadTzBbjGRVDHqBRq2hpH1qIKsu4sJFUadP0CfutHP6BR"
    "U3oGtWBvtS+HhhMSqe3melK5sB7fz+2uSmrJqoFvKsk6Xk0tykpwqKK2FUVkwLOY4aMIav41m3q+yyDTbYgtMpJVjc8La6jjOOK6"
    "06gJ/W7fV01Wj5J6P7VTnzyHmjts1P5oFjWWR1KfVUE9O6HBd3XgLqOBrdnU8lg9tW8uoK5seATfgdYE4K0wkmmSlZrx3mhdGktN"
    "+8OoizdT47hq6lFZSLUNeB6sIcOoMup9XUbt3XnUgnfUntFYf1pDA2c5Mn0VRY2FSoLdSXUUWp+LpyZzFhlsCdT+UwEN7Mmlxivg"
    "1Z/KqFFbQ00nlNJfCtvIOLGURs5IpU2Tq0gjlFF/YhydPmql7vEldPTRJCp8xEzGRSVkjIylBaPltGl6KTV8ryXNLg2dDskmmyaS"
    "bHw62abLaMFaHU18L5QWrI4ly9pQOk1x1D/HTJpIMx29Tk4ry6tIv7SaUsaX0+m3E+jg9Qk092IqTZxsoAVCMdkW5JNtaA0VflpC"
    "k99LodnGJNp3N+o9nEITZXKaPDGPZm820PguBR3cq6KUL6upMCKUjClhpHAZSaPLJ43DSIqGRNIo1KTA97OiNJcUBXmkeSOdFN8V"
    "kOIxjhQvZVLDdgU1/MhRw6J6atiaT/uKiBpMGTQy10zd3ghquAoxL1ZSwweV1D2tio7OIdq2TkvbbtfRpputpH9MQ9N7jZTSYafl"
    "2ypp6WkVjZmSQptaEfNsKqXcnkoHJ0bT0e9NdPCeSJpt0mG9giwTlWSbEkcWlksXv6iiFLxz9Q+T0/LyNCrcHE3LNyXR0fBiGh8q"
    "o4Yh9XTw40TaFK+j7rHA+20YHV0fQcvv1yAW9W810sHCYlLMMtICSySl7C+hhteLqcGhIwX2wDbck1cifvyOclo6VUnj344n45AY"
    "mvsvFR30FJN+RDqN/K2U+lfX0kqnjdZuNtHIzTU0+y4LjclLIEVqHh1cZ6f+46U0Xcil8aVaOv2qlQr7U0mxoJS6K7SUYg2jBfZo"
    "2vabnvRTK2n2VOAan0GbGsrobJOFRsJpax9PJeOvGTT3XAJNnFdMa1NrqP+Lcup+kujoD9m07/4aGnlfHU2fqSbLNwbqr4+gMZ9p"
    "qAHPAfqOIpq8L4Qm4/1x30R48pSBFHgWMC5S0abRsbQ0uYwmf51OZ79IJf1peGaviZb6ymn2PVW04GYlbcIemT01jPT/CqXpC6LJ"
    "VhtFR78EL7wnLWhIpcKPEkgTWk5Gu5UsfnjtvjjapysnxfEs6ua0tC8ugyb/hF6My6IxfBRtsmppcq6aGgpKyPJhAk3G89L0m0vJ"
    "IoM3H4ol2x70M1JLczXZdPpOJU1WpNHRa/JI/2whnR1WRCtrrDT+UB7NHYilkX8kU/8f8TT5AwWN3B9J09MqaeWBKDq7IoouvlVP"
    "F+dC51eUdPa8hfTj0CdtAdluz6GzqRWUsjyaxsdF00HcM2y4Ry9oUNHK1ijqfjuNlr6XRSNxD+hOjaKJrxto9qkqUmSU07bEWmoo"
    "hx9icqW/tM6kmqQkmpBhovmURmWcmipfxjVPHcnzlSR/uoYm3GGlk1o7rXhMR7tvDqFxfVaaMj+S5t0eT4+wBFp1dyzt99XS/D/D"
    "6JFz1XTGF0s32OspbZyajjAdrcGTxgSTiR6ZVEUz24toxvocWnPERplTUimzK4L+fLmM1DdYaJwnjewzlLQ9OZOeO1BN8YfLSW3I"
    "osUTk2leXQXNU5fTihoLrcK75LxHMqhYXUurYito2St6sq/IIG1zBOLDSdlVTfIzlSRXx5Lcbqf5eE6bfz6Nnl6ip9ZbOJr/QRbN"
    "G1JCK66Opyk6C50ZmUjnKispH+8ld1Ul0NdrIunrFbE06ds0OvNxOmXOiqOvq2Mo//MSWoP3mxUHjXRydRSde7+aJn1XT+eeD6EV"
    "i2toVWYenZtgpq+PpdKq4xF0Bvfo+XUpNP+uRJo3kEFPv1VJWmDR4ntKiXcV5ZVq0j5STnJVEcm7ykjL1CRnZSR3JmAum+RtMSS/"
    "y0DyFRXU+l0CtU7IotbldmrFXm/V5mIUU+tHcppwLJ8yXzBTpjyLTq6spBWf11PmN5F08p4COvlOJq3AO8CElVG0YlYqrViTQSs8"
    "YXSySUMrPsE57tOTPkqh8y1lNOnXcqr5vpTW+HQ0sz6ZlnUqKel7PU06GEHLnKWUtDKS5u8JpXF4719zZTqd2VNDyz5LonH7ckj9"
    "poEmva4gtT2FjuQX0Agn+GfU097zajqj0dKykQl0pL6I3v0sC+vyadKXhTTu7giaZ7HR7rYoyk9R0ZFN4IF38mnlRdT6UD1V4rlw"
    "NL5H/xxbR/vd8XTDmnBKm2qncw9aaWZ5Fq3fmkHn7kH/9Upa5Y+ivX/W0agb6mnSh0ZaXJVKE6YmU/HnmfT1mFi664Ns2l1koPld"
    "Vjp8WkZ/Ogtp8T0yip9YTNPkqTRzroFmKoz054V6+qkuk/a/SDRjRgG97NfRraO0lP+vSnp6aRRdYTTR9m/1tOpwDo3+qZqm9RRS"
    "8YgkmoLvryPzomiVrpLO4H0tZ0gUHYm3UdL9SrKHJVDxnwqS31ZCT79qp1H+SDrcG0sv53A0RZ1Fd8kT6OmXObqyuZ62tygpZ1s5"
    "TcM77giTld59v4jseGdQX8ymYxvq6NwfGXT4wQjK35JHa3aGUesXOTQlSU7zUzg6c1csZe4OpdFrq+nw9FC6YaKJzlydSK14Zz0Z"
    "X0GjfjLQiGIF2b+HVzrSpb/+L6eE3Fx69nojfSzPpXBdHMXhnV3mriJZXAzJPsynHzcX0tSIKvp5p4FePxxBp2YY6RU8A1/zaSn9"
    "c6icLmyLoSFmBV2HZ/SpQ0NouJuj31dn0fv3ldCdeI65F88Y2UYNFeB7dvXsHBqKd6PflqTQd7hP3aOvp0ej1VSA79rv3EqKXBRC"
    "s+QVdPXRMkq+oKfktYX0wwNWmvVCJQ1blEzXZaTRA/+so1mFMRSxsJK+aS2ha07YqWB4AtVfTKfQpQUUsVxPobJSCn0hjyLqa+hq"
    "PPtda7DQnh062rWqiD5qTqWPJtVS8iYDzYrKpweKtPTHyRqaurme6goracOfZXT9dQn0/L1hVOviKO5ULr0yQkeffR9L7+3Ion8V"
    "RdHbnJ6ibaH06HAdfX60lg5dTzR2aAUtcibRha+S6d9vVdH1oVp6/2As7epS0p5aNV17giiiSkaRL5RRyFVFFPpvBck+qqOoBTkk"
    "KwylCCGCQgQVyTqzKWSBkWTdiJtaSyHvlNKOsZW047d4GjqshHYtiKQhTxMNVZTTkPXp9Om+JLoeeRbNqaMl+ij65D4ZbSiLpk/9"
    "RbTk+1oqHaOgjbOraMOPGXT/TylUXp1G17+eSRsbwfmPGrrmHzL67XklrT5YTuuqbXQtvhsehu/GTk+j0CMJdOi0kd6+PpeqpsXT"
    "S29WUXYNRz/gHXAP9vizV8XSm9+UUiqeJ34o1dD7yfkUtTSVQqfFUe7nSrpldxalqzPouCeEPsM70I1XVFJcppHeq7PTnc+p6dCb"
    "crrqUQ1lz0ylmwyhNOsWJf0wJZ3eGZ9F360poeQn0ykP72wf3VZG9epEmnNNCv2cKKOrIsJp7PlymnWxjHLTZfT4/hr6/poIeKuQ"
    "/rE3hh4eqKW8l4toSHIF1WLvpzoq4N0q+jTOSPdtyaSQjfn0+lg9Pb+lih6ak0Snug20Rx5Pt7VG0A+311NRYRI980o4be6oomuP"
    "G2hRspYSzsVQ9HV1tGF0Ff22r4YSbagFDa9qiaPs3Hj6YHcxJV9roR8+jac5mTX0+LUGeu0ZDS1k2XQVvp8+vVNO78Va6dPeKPrn"
    "qEwK+6WMTuxOoKh58fTMbzF0/ex0+qC4nh5/qY5kR6PoTeyrHzMLKFVZT7fPMtNxQz3dxifQwnAjrX4jg2K5RPpQVkyLbi6kjXPV"
    "9PiBXPrlHzq66nwIvfYvO8VtSKDfFTV0v66IhhpKacj+Wtr8XDpNXamiZ5+vDfz1P/57bWst++b3Svb9Y/Esrr2erV5UzeSqfNY6"
    "38Ae+zaGJc0NYx1zatm47+rYz9VhbNs9aazXl8MKr45iz55MZdo5ESzDqmZ5PhNrPBfFQpvD2AP2KvbZTxq2jLOy41TMjt1QyRr3"
    "1rBoZS5b2ZLGLh4oZOvP1bGwc+nsXzeEsxebEtmErhjWftjI6udpmPIuPXtjVinTjU5lXcdi2OsfGti8k3nMwiWzOUcz2XuacLb9"
    "oXq2+ISFuT+LZ0+dzGGaNTKmHRHKZKNkrO3FNLZgj5E9nqNjp58xsW+j1ezNByzsnt+17M2COja5P4K1NhjZwtg8Rs1yFtJmZBpn"
    "OAt7t4apx3Gsrz+f3ZERwXwf17OODTLW/G0pyzulYevsRvbmKjmb8JWJTW6oY9++nsIeWxHFnsgjFtmlZaHOPBZKBiafYGch6gI2"
    "4Y149tUrCrbaUcSMiiLWOlnLHhtaxlr/mczmH1WxZ1w1THZAx6K+5pjKl8TIF8tC+jSMdoYz2aoC9tijxaz1Cw07OSKc3bHBxjxv"
    "5rA79qrYySFl7MRTanbH82bWM9nAkoqj2PAeJbtQVcp6tprY3mg7++5fKnazRc0eul3NwhF73lbM1HtC2M1VHLv7WCn78JSKJfbL"
    "2D1jzey8UMMmUQSrzg1neeMq2cAKYsneGvbiVRz7rkrO3s0ysFnp2ezMtjz20JJk1vZJLLt6ViK745SFZTwQw06dDWWvDZWzLEUh"
    "y/hEySb8HstWeLIZl6tkdywsZCy6jrVeWc0ecxKTxWiYzJfM5KwEHowHZx2jDvShEee7sxi9W8VIDS22x2KEM/ZhBGPoKzuuYsyp"
    "Y6xBy5i2grGbaxkrj2bs2WLGHkTchkLmrDEx7sNq5lmHYbIz30PlzPlGOfMlJzHuVivz2OsY11LBPLWxzHNvJuOsFcw3LJo5fQrm"
    "DCtg3I545vsxgnmyqpjvYDHjQmzMObqOtRQpmFWdzHrWmVjHv8tZ23I1a3oon7U/ncOsEypZb0U463NWsr79eczwTi3rub+MNVdV"
    "s8YLiayvIYFZry9lLZYKNpBawwyrK5jVksU6rImsyyljLbuMrLEmjKlKC1l7fCXrKuZY091hrO+bWNbxQBHreDyDWf9lZS0HCljX"
    "15HMuiGRNb0Qy/oeSGTtymjW+24oa+RTWPO5HNZYWcH6ci2sya9nXQWRrCskhLWm5rGTz5WzUTEGNkKbzewbM1jmuaLAX/8L9fzU"
    "sXH8FzPChRlDIwT7vlph3+dFvEwRyQ8ZXiRc8VA9X7jXIJzuKeK/Gl/A64dV8N6qEKHix3DhrbMxwjhHlvDETrtwXWGFkGqOFRqG"
    "KvibN9XxmasT+PBdIXy3Q8HPI5lw693R/MUhar7tmQph+5g8ftnHemH2gwaBezCaf/n7ZP6KtXJ+9yY9/3BvNW86Xstrs/L5KZU6"
    "vur5BOGHtBj+qr1W/vpDVr6sM0OYOLVOeHizkT/1WxX/2ZtawfWVnN/bHs6rT5Tzij90PJVECh/syBZ2fWPnu63pfNUXRfwsQ5aw"
    "dGqqcL+3RrjekC/cvCWZH74+XBg2r4oP61YJoUetgtKh5MPuqxRC8rSCo8smLPlczVe7zPyNT5fw45rrhC9ddmGruZrv9MULD1IR"
    "f9s3ZuG9GRphT6SdH75LxWsVKTz5NUI4FfKaXRpB/Wwdn8hIiLupRjj0Rqkwa7lSGMLs/Edv5PA7ThcJ+/JThatviRDCN5TwioXp"
    "vNYfKYR0crxsukmQ/aOKD/mykh96vpjfcW2+YM4r5ac1JQo/1lTxneD3VkcC/+lHaqH0Xgt/eHYKH/ZgqbDgjnI+5QezMOxYGj8v"
    "tFAYFqvjL2bKhBsMBn7dVTnC6TEm/lxOvRBXGyUcOmMW7rRG8P94MIO/9kIW/8spPb/yGYOw7mAGv6A/ld+WpBf0WXr+/bu0wnNj"
    "M4RV79QK/7gmmT+nChUOTqjnXymNFA4fzRNGv5zIb7xHLbjbI3jHq9W8W5smlP1bzm/cUiM4Xq4Vpp2384s/KOaFR2uFHQWxwpDE"
    "BD7kOyUvd2QKJOgFgjfIHMdTg4qn7kiBXkX/7qjn6R+pAn0qF+htvSB0p/HC6EyBX5wl8D+X8IJPyfOR5bwwpYLnrSm8MC6DF6LC"
    "BP7PfMHfaRG8I7S8zmjjO2+IENxR2bxreyFvVtcL5uos3u9IFBzKfMH1XKng/TRScO8q4825UbxOlyfoHucE3Tclgi5KK7hvDOUd"
    "32oEL8ULjjdD+ck/RfMN43TCGF2YsKmtiJ8cGyI0vFzOWwpD+Mn9ccL0EXbeUhkr2BbmQPNIYVNxId+dXMGv/FXLr/1HKL+8OJcf"
    "sy+FL7yvWpi4qZRPmRIqdO9KExb4MwXjq+W8zWjlL74Szjf0hvP9O5L55aOr+QXXmfnJtnhe313Djz+eKzRcbRCMCfXCvjOZwtFf"
    "QvkF91Xx+1qVgmJthnD2jjR+24lQwVKTJEx/topXXAgXxj9eLSx9Ikq435HDD22yCUNuJX7z10Z+6huF/LOW7MBf/3Pir/8cR1w8"
    "53vVxFkXp3sS7SpOPl/r8aytdK4gAzfhRJ0zZI3SJ/OlYk0x59mbyE2ZX8TNm5PMPXLEyF15ItoZvtvu2dqm8FyYouR0Z0o84+zZ"
    "3L2mel9Bk9p3gBm5l4/FOj8uS/Y9+4jcV/J0iSetzeBJH2VxLnra7tnfI3P+sEXtUx3J4ubfmsj9a2wp90RNtmdDqNWz/ECqJ5Qr"
    "8RQeVnk2TCdP3AA529frnFHOaN/jW5OdlhGlvvc+VzjfmlDuXPlUrO/x9hTPwt3ZvhX5Ft+p8dm+1W/WcXMn1XILl4U6MwcqfF+d"
    "1/jWR2T4Jt9Q4Fm3K4X7dmwiRxP0nHKm2akesHieSJNxC9dxztt3cJ676tM9Zz9O8DzlNTmZNcrz2laNM3+NzJOZXO153B3pjHTm"
    "eBSLEz2nE8J8effmcur4Gg9ZI32hVOl8sjTc+UxDpOfEqEpu8oUo7imD2tnWqHR6xli5id8Xefo+S/Csu8vmvOftSt9ToxUcO17q"
    "UTdrPKSK95CyhJszppqbc7TGuaKMc074IcG3daPMM/x0nCfpxyhnW42Ma4mt5W4qrPW9/o6au/2w3pcRW+t7NTbVc8dPmR7uuzCO"
    "5PGeEFbhY0vquYGhSc6nJob4Zj0h49R1UZ6Zb6d55g9wXPPMHOfWjVFc88flnvM3aLi+HaGerSlhvsYR+dznerNvwKx1/m4I8ahe"
    "MzlXbM7yOG+P9sielvvk7dVOuU/hax2l5QZW1XOzyss9dxtqueEbM7i2iGjPzd+Rp2esxTkpvIb7YGeF77spBZ4sTb7v1MUUX9Yd"
    "ldycaqNT3lLnJK4CTwOcj7piPXTS7KEJJo65C3ysv8TJfsvwsY9UTjaC45xOq5N7N9LpuTef456U+XyuCJ9Ho/I5vw51cksynZw/"
    "kfPEaHzchwZf84UcZ7vGypk+qXY2fa/2tbRG+Nqfi/ANVMl9qnP5zra0Ck9jaIbT0JHgGyiO8XSs1HBNZaVc+x/w3xUpPtOYaF/L"
    "RyFcl1Xra2s0cX1UzzV+zznz/1XMPa3P812hsXDbh5T6Vk2u5Q50VPh+2qr0rL8Qyp2LSfCNe0/GXTk5y7N3s9ypLA93nr81h5t5"
    "TZzn2C/5nv2jTNzJ7Qme9co8rtgu82y5I9355wnyaD+s8/xZhXz6TF/xzkjfvGMqzyMerWfEt1Zn68OVzp++KOC2TIhzLn4q2Xnl"
    "bTm+LW9W+Ka0Vjh/0oRwO++1eJbtjPBU/hTGXeEuccpjbb5J63O5d9+L8T39XJzn3FVJntF8vbP1D/KdrIzwjVIXO0ccrvJsfzzP"
    "s+KWosBf/5vFX//NZnJU61w/2XQpnxf4U6MVbhoW74gdXeB4S2br9LtKOkOezzLLHMlm3K91jlC9+ZXxWbprdpnN/zybprtnWqnr"
    "8Qty77eKSFdBSJT7g8+LdedWW/wFZy2uW0ZG+T/g8x3b/yhyxS4s7WzNinP8+lKE2bFc7nr2Kq276YmEzucumjtv/0zpvXNWufla"
    "o65z2Ia4Tt4T7ro/2uh4oNfgMnQa/NWnyPuINcmfto/T3TQjShepy+/cuTver3io3HHvuQLHfsR9uDPeu/fTVDfv1Dtcm7Suyly7"
    "e8udxa4Rz0W6GhrL3WOqCvzvfBThHttmc103S+bW+03++hU2c+ihqk75VckOlaLIf8UTKZ0Ns7L9bmuZefluk8viStGNnKh1fXgs"
    "wRzdbTX3f1Pun8nsjp494e6oTrsu9BPO/eVypf+5qZxZG17rluuTHGqq8g8xpjqGTrQ4DrUodYf7Zf69EUX+xjMVrl8eyXNc+DjD"
    "/cufMr9Vn+T9cVWIbti9mbrds/P8WqPNQZp6l3xOlkv4Pdq/8zON16UzdF5/vdz/dnyJa/cGo+6XxBz/utut3pKBQu+/9QXeYeUa"
    "96dChf86SnIf6Axze68weBf5c83yyGqvjC928zPT/M/n5znOXZfpyrmWc537xqib+Fu0+3FXoetwit6VMC7KdW2fyd1fmGP++r5S"
    "87kLJY5bs5O8PyTHmMO2lrn1J3I7vzpW5r/+rbBOx+gMR8jVMd6QyRpdiFet21Go7dzTEt2Z+rHe9fFn4Y5Hn4h2zZ2r9I+cFevd"
    "cybCcVqb7L41X+ZOj1O6O7XRjvJNqZ0HUqxm/qLNK9un9cv85X4SMjupod5PcSleOlSt49stXj4io1P4o9jFF8ndwpdFLtcii0M3"
    "YPQ77lPrvDtL3N4XSt3+Ns7siikwd44wwp7yTl1Nsl/n4nT6MQrv7OJQ3dLh2ebZndmOBXytbtN9OWZbc4p5zMY8h2VIgnn2vEzH"
    "8q3V/qWVSu9IXZZ/vDXHf/S5XG//q9mdp5+y+ZfebTGPt8c4xryncOjnljqWzy90L0rO1yUUx3ZGh8brNqyKMP/2TKz78/Jc1+p5"
    "NeYnVobAuyGuJ1+s1b1xc737eLHWOzVC3/nLIymuT5clddadTXbcOCvV/9iSXG/RY4WOXfdbzA/8Zvcn6KL8n2Tmd16YVeI99XSd"
    "P32V1f3ebVXujGkpjnXPp5mX7CnVXaOJ9t80ptr90ROV7qfKQ/33RGZ4Zd0ac+36HPdtZ5LNe07LvIdGxOrSbSn+3z+I0+24Uukv"
    "n2f2rv4u1zXcE+W+9x95/vudOv/QPrljyDRybJ5U7NogqHWH1kQH/vrfZGrPIoOKWtJUzZ9XGtasC1PhAaCRmWo7wvOMpprItIH2"
    "c6m9rVEmlayvwkBMpWpmyrZeX3Fb4R2GtjhW1XE4IqNl2svGgT+ey2tfvD+7bZjc2nvvdl3jkXfTO54+UNUz21nbci3jeib3lrfk"
    "+0xdclbX+ML5asOZnPLe/sq4pq1pVU3XMeor8djbniJr8+tjoxtT+zJN1VxSe/nout7MgfRm9yFFY3Z8SW/tAV1HSUdVW5oqu1FG"
    "1q7nbs/pqLtS3bStNbOvnioH1meUmFb8oeiSN0e3P7Euo6voeHnTieGJAyeqQ/qoydKummFTrd6Vp/r636qOp34qb/+mIq99wenE"
    "pscLTL2KZVyX7wN9ywmdru/Jp2LafEZl71cfVzR23FHc9k1VRO+8CZF9T6VEmCKOhKvuvtPWLjOYOp46GdnbegW1mH62Wp98LGFA"
    "oa3tCWUlzXmF5YbvM5QDbRtDupS+mN7X28JV6+fmdmTrohrvvT+p7czxor4wQ7JpYU5U+5RZ2c133FDQRfPLTbLW9IE5+xK7Tu4v"
    "tvqO5DX2PaO3ti+kltZ7dIbW8UWqd+aGWZsP2dpbhoe2HzloHSiYHt+195yq4wVZePOkK/LbX/hO2/PdQF7fY62yJhlX1n77FbXN"
    "n2+29056p7zji+K85rZoW7PsWH6Lc0uqacU3UabXovS9ZxbnqB7aYOuJmJZvNQyP7TnlN/V6YhNUJ1tszXMc6j52e/ZA9cZU07J1"
    "8R1z7igZCEkqsMq6knpfPRremGy19X7xXX7zpLfyDR/0hHaFjMgdII+mcU5FlXXO0/J27iFF24n0jJaaZ2p7ql/MH6j+obYl4/OI"
    "djpT2U4Gay9xVgPdpbOya+ua2KhYleeUsc2zX9PrS8zt8VysbfK1RhpUt9p7u2429rRMqmlWeeSGxtDcnuZrErsaL8Q2t+xNtxpe"
    "sfa2v6s1mb6sbBy1Pqxn0kumrpgl9oGTs22m9a/Wqe5alt08j5c3fh2pbM7PSe37taGs79ghc+NbX1a1bClWt404pu6S15S2xDwv"
    "6/rVmtk+6Z3Qvl/tut5HTmb2zNid2RQ/q6q3pSim15qf0dMTkmvq+DGlR/VoaG9LKtfU0i03GJaktA3cXNDR9ky1iSnL29k2exu7"
    "Mq2NOuoaiZJ6SR7ZQyerTb7PY5u4PZlNvmVxfb62hD5fR5TVd7jelDYkemD3xbD2UbEyw6qXQ0xpI+J79j6jMMg9oX3TQgsbK2+O"
    "Uy0eami+8ri1a8vvmsYZJytM6pTq3vklCYbMJYl9+52KjkkPqA0jbgxtWrEiveXAjtzeG2zUdcNoa9eZivze1l+K+k6mcS2jVGHt"
    "I/xRbcduL7HKn7UF/vrfZptYSkY9bSoq3DQ5WfP+yVwFHgA28Qeyu99PKZ/8kjJ839mH6ycLkSkLZOOjjCRobNOHVvVX/Fh38S2v"
    "5eIyvuzgVm348lGr6w9O2qHfdvz+0v7aItu+3G9qRi6pT52b+0eBotIb1v82X2fZfVSx71pv/KYGgbNNDCldW/JF6si3llg3cZ9Y"
    "Uj4QQtZedFdebKq2LB+yIXtBxezC5THm1LPJz4el5K9N1d/4UebSwnWls0s/MB2sOFg9xra05qKR9GN++SFxjDnKMPL7Huu2aKqd"
    "++vqtLlpr1Z1h45J6xamUPdDWyJXmt+1rZx5sWileluKUfFM2MqxswtXvlCkPdh4T/GmsmmplpFzIjYNvxg3Rvll1vSZs0IsXWGm"
    "MTvHmg4eHVKtt7ryLNffYV/63K7qfbvyzLbGp3IvhmzIsk3no9ZGKFLGC9em7ut+WLfg5W1h+/bfKltLi/KOqvi4o9uy9Quu82Yf"
    "7Y61p4S6TLbPblOute5Ur924rGJkf3zEgt/O2yaHL1WvHdYfM95xtqbw33na2YqrMhaEXBt/cdfZvNNLThTOjb2pVPPAXsPKhl2h"
    "a3c8a9u24+uqkWF81bZjs8xHCwvq525/wDxb8ZJ25eHNKSv3LJBNT8uJsuy/WLry4Hn18l3D8k7LHOnTD3yXM/murtQFaauy9i2d"
    "Gn+xqDdyLZXUW2IOhe/buLV69tRw5b6oZ/O6LS7T7IoXq8ekr0q5GCvY9y1arFwQe7Bq8s6wKCM/YEr5pitl+Qx/yumdz3Jj6FXt"
    "JlqZMTJ2pH3yoeN5c8/6oy5+dNI+fts/ki+GrM45KPt/AaYJWfbQFITDmDqMwkY5pHMHI4xTmhDkrUI4NORgLAwX3wUkck8oXAHT"
    "A7wBzDfEADA1XAD3GkTAVR5EwEYH9DDyOYTQKhEMMCgOpNC0FowQxTHMFBw6BGxPFHRsbSIkjNcJHByAHsS0LRA8lFkr1AQLH3Tk"
    "Vy1kfPkiFPx/JKxDeS0EZ3E4lL3vHHTpPyrcARcOjHvgKVwtJRRkmSQLdCOVOeQ/5BdUM4gCFDlOA+TH6BKsVYwJHO/1M5wjmSQ0"
    "q+E/bGsjBGQxPw0sG1ULFKFlMDzTgRKUbPIk3EQqAIRUgyVstA0fJCxmNJQU6A2cJKE25LyMF0QkbjVsJKMKTECEF9TApDJUQKA1"
    "tAAEKbwAADPsAIUITAD1MbxQog9kkOArjNBEEKyQ1z2sUKoIbPCZDcwr5y88s4c8fK/INyRNuAEsMZc5DO2HPCRTtTUcDQIWJBmN"
    "FzTNIyg8i/MTvGvCKtR9sgCkl7cDRIOOBXRbHyzkAVcJDCNqCqR1KT/kNVcenIdmAHxjNBMcFdwflPn9H8RzrBE8QxQ0vEH3P9S1"
    "nxhEYVADHOVvGQIAAAAiIiIiGhoAOj4AAiA+igAgsgeyNT4IoBnaISkb4gIKCM6ijgR+A+A1MuIOHt4D4gsOAGAyKvqgDxZuihsu"
    "hssyOl7jFQbgaB0CAAAOAgB+BQIAhg4CoAgOAiDeJQIeuj8C2oo1AgrYCQKCoDVizzI74pWYFeIPICGifvo7oj0AKGKz2CKiUDY5"
    "YoVgPOKyuAreJyACTrNVOeYMDg7+PIgI8oHSJTojQiSeu/UpXoTCPiqo6ATyE/INkgRyNiIhAA5KMSolJqURLPqjuhLKK4ACRgD4"
    "OsYjmxHiBGItZmQDIqIPaDYyBeAvMoKcGfYAHjUSh8svMqqpKVKNiSOKKbE5+uVdFBrqRCvaZx0I3oO3M3rrmyO+iw8c+mhhBdqI"
    "bQbK608PGg1oNjrjOSjiqAEhIqTQM+KNZwxGijA1BgwGBobiIw/S5b8f8qYSI5YsoQg2it87tgwgGdKotxpyga4nTu8YP8oFKAnu"
    "hjIzuim2EKqMzgPO6ZAtCuJdM64L3jXq7JkYOu6pBg4Dfh+ajS0hvoEiKQ5h9SyyyRMP1tqYGBLKLA1++Kg3HuOqEGLguye+IaEC"
    "ygCAAxb5VSXeuycSwkpjOYrguhGugcc2Ous9LyZ4xzj6y3kNGiNtPaIAKDjOO7A1ToM8AbIDfgXuons1EirzDaaB/jMqi+4cokix"
    "EhYYCj8WSxQQehqZB6ZgKglaAJIFtknoGbJZXwRKG6ovCuOPJ15j9ydqAD4YChvcGJbi+DjSgX4vTgI2K6bKLRaagM8jggMgMi7r"
    "Gxe2a1E+DoFVPJID+BnG4cwmJqCgBUZJjwTmidk4QhglC8K60x4io0kx/mnsKCaDsiRKA6Yi4gAoNq6AHTTaIKgGMiCgMIa4LxAS"
    "yJsiHog3EPK43hhaiGUjDv67EOJO0gIK1mse2j4YNTqOQTL2MlwbVoZsDX4WqB+WAvwy2r7dAWrijQIOYBQxiqCJGZIAgArmAJoI"
    "ooD4Bd6A1iXWmNEaNqhzA24oeBSaaLMRPhgoIqr4BjrCqEo5fpKnO6oa7jyq+hAISn5UGSrykxiqdr0xIn4oHgLW0wZidkcujio/"
    "FcKOrBcqwscexj6HOgoGtiBSitE/ggoUN/o2GzjKFqcSYtJQIp7gRBweoHYDVqA0OKYAgg/mAIALzoDFD2qA+h+KmJcmUtiyGgIY"
    "4SRaON49AigpOuY4fz4ChlQjgu5EMl6majZOPogV0qZePfaqQDrmIioXShICETqWEA2OkvEK8kZ/GdI2ohXugGwPdoCtOCIAOAYC"
    "AGABiiA+NOrg6TCWoMMV4miIMIaIsRviOF4ksjiMA3o4PSVKgh8reuKYLlLOTwO+yu8K/hY5M1J6cRMBAAAAMzMzMycnABcdAAMw"
    "N88CEMknyS4RBPAdedLWNWEABQRnssozBwJwO5VyCye1AlksMQCQGxWzMisBn1wSFU0uCyn1Uh8tkL47AwAAPwMAtSUBAN8CA5Bk"
    "PwPQdzYDxT8tAWWxGANdrDgB9bAEcxONAbGCfBJT5rArM6ADNnN+ADyRM+Q9sdm9M7GaUC7THrQAXSQwM7NQsRljAx8fZy3sIcdi"
    "2CSrKscoR2J9KDlsRQUFZOgGxybHL0khmRGBIwAbeTOJJ59kKhoF0dQwkQdANeUDhBXjXNEFUQdFODH+BDdxB9QXfQlQGl1GRwV/"
    "B4cW6cZ5Dj1Q2zcbysYdhVbbBCMwPhlxcDkr870eHNHJeS8XeEgFl0sODo+XaChJRLw+2T6wBN0LdCK/mkoF1xqZEZexMRzTx9EK"
    "58R3JwECDydDvqsVvd8YFnvQkw7NnB0NacIvPB0GcCj5/+YB70WBPtfdkwvTCkwAwc3GHgF94xkpTLcjjTHNAc37vRgJB6saybXG"
    "C+8cwTAbA1E+ScYZD8tBUQLnMU4pV97SFvecuyLhRR08pRW1BNUzeQDpsts2SbEwCT8DwCuPbFI5YyyZABU1MC0RkjIwpcCnG7dc"
    "ADxTXiQMFUa5FL2z+w01AFw6qy1kI63B9SyDAIERwbDxLWNeRiidQNoPnYX/MkGnMDoBZIY+hV/ZHscFRC6vk1ADUQAxBrVclil9"
    "LHcUbxd+InsTQAR7M3oP7wB9LF815jU5sOILQ8O3Ea0D4zXPFdQVR0EoFMEAEBPRjNsD5eyVK8dBLxxpAGQJz3AuGZdRngtpnc8t"
    "yYx3IjUd2yt3JcIHV5DoOctXNTl5wqEWQwM1I3sAxCapwBQu5dDHF4eQNDPXdC493aSxH10EnTwjhEQZzVS3GbEpSyLnDXkg/39v"
    "LMFRPwIp4+c02UNzE4Wx4gl7P1gPdwOhO5c5yBmREREqJfALOtuQaiidAEACUwCvO+dAzCFbQI0Xx0zfPNkkaSSJxHUL0Sz5Ituc"
    "exqHlAIxnUzZM/9JdjGH8+kTVQdYHZmfiigL7/orW3F/NCUbrgwBMV0LjYPjGjuR2wCbF+oJvVHkOBnxwg/1534TX52tJK9D/QoD"
    "+xEOX0HwPRGtDwBRsGAiN/BIJG2wiStZAEMd1QBACvHAoiKrQCY/kwRbAPu8CwCPZNUwyxxPJ5mEayObTMkbV99qDIHf4REpI/gf"
    "ewlgGA/FDxJz3acwFeM7Eg2dhSNNCX8T/824EzeLgxSfq3EW30BDPdNAHzbVAPQiWwBQD4PQ7CJRkK4kBfAgPkGkUjA1BCshw1Si"
    "GL+cUhZfVBkYGXNRNYVDVQ2bAdcUc/W0PRfl2DqZyfkdbzAHzw=="
)

_DIRNUM = None

_INV_SQRT_2PI = 0.3989422804014327


def _direction_numbers():
    """Decode the embedded Joe-Kuo table once per process (stdlib only)."""
    global _DIRNUM
    if _DIRNUM is None:
        import array

        raw = zlib.decompress(base64.b64decode(_SOBOL_B64))
        a = array.array("I")
        a.frombytes(raw)
        vals = a.tolist()
        _DIRNUM = [vals[k * _SOBOL_DIM : (k + 1) * _SOBOL_DIM] for k in range(_SOBOL_BITS)]
    return _DIRNUM


_PPF_COST_PER_ELT = 168.0


def _cost_per_sample(width, depth):
    """Analytic per-sample cost with NO pruning — deliberately pessimistic."""
    matmul = depth * (2.0 * width - 1.0) * width
    relu = depth * 0.5 * width
    accum = depth * 1.0 * width
    sobol = _SOBOL_BITS * 3.0 * width
    ppf = (_PPF_COST_PER_ELT + 3.0) * width
    return matmul + relu + accum + sobol + ppf


_BASE_POINTS = {}  # (n, width) -> unshifted Sobol integers, built once per process


class Estimator(BaseEstimator):
    """Sobol RQMC with dead-neuron pruning and an aligned input basis."""

    def setup(self, context) -> None:
        """Build the base Sobol point set here, where it is OFF-BUDGET.

        The unshifted net is identical for every MLP — only the per-MLP digital
        shift differs — yet v2.0 rebuilt it inside predict() on every call: 30
        bit-plane passes over a 16 MB uint32 array, i.e. ~120 large-temporary
        operations per MLP, and large temporaries are billed to residual wall
        time (forum 18101). Building it once in setup() removes those 120 ops and
        3.8e8 FLOPs per MLP entirely. If the graded shape ever differs from the
        context, predict() falls back to building it lazily and caching.
        """
        try:
            width = int(getattr(context, "width", _SOBOL_DIM))
            depth = int(getattr(context, "depth", 32))
            budget = int(getattr(context, "flop_budget", 272_000_000_000))
            log2n = self._log2_samples(width, depth, budget)
            if log2n >= _MIN_LOG2_N and width <= _SOBOL_DIM:
                self._base_points(1 << log2n, width)
        except Exception:
            pass  # setup is best-effort; predict() can always build it lazily

    # ------------------------------------------------------------------ #
    def predict(self, mlp: MLP, budget: int) -> fnp.ndarray:
        width = mlp.width
        depth = len(mlp.weights)

        log2n = self._log2_samples(width, depth, budget)
        if log2n < _MIN_LOG2_N or width > _SOBOL_DIM or depth < 2:
            return self._analytic_only(mlp, width, depth)

        n = 1 << log2n
        w64 = [w.astype(fnp.float64) for w in mlp.weights]

        alphas, mus, phis = self._closure(w64, width, depth)
        basis = self._alignment_basis(w64, phis, width, depth)

        # Alive/dead index arrays, computed once per MLP from a single
        # comparison per layer (v2.0 spent five ops per layer rebuilding the
        # complement with ones/bincount/subtract/astype/flatnonzero).
        alive_idx, dead_idx = [], []
        for li in range(depth):
            if li == depth - 1:
                alive_idx.append(fnp.arange(width))
                dead_idx.append(None)
                continue
            a = alphas[li]
            keep = a > _PRUNE_TAU
            idx = fnp.flatnonzero(keep)
            if int(idx.shape[0]) == 0:  # degenerate: keep the most-alive neuron
                idx = fnp.flatnonzero(a >= a.max())
                alive_idx.append(idx)
                dead_idx.append(None)
                continue
            # A Strassen level halves both matmul dimensions, so every prunable
            # width must be even. Raising the threshold just past the weakest
            # survivor sheds exactly the neuron closest to dead -- it moves into
            # `dead`, where the offset below carries its closed-form rectified-
            # Gaussian mean exactly, so this is a shift of accounting, not a loss.
            if _STRASSEN and (int(idx.shape[0]) & 1) and int(idx.shape[0]) > 1:
                keep = a > fnp.take(a, idx).min()
                idx = fnp.flatnonzero(keep)
            alive_idx.append(idx)
            didx = fnp.flatnonzero(~keep)
            dead_idx.append(didx if int(didx.shape[0]) else None)

        # Fold the rotation into W1 and slice, in float32 throughout: v2.0 built
        # a float64 list, cast it, then cast again inside the offset path.
        sliced, offsets = [], []
        prev = None
        for li in range(depth):
            wl = w64[li]
            if li == 0:
                wl = basis.T @ wl
            w32 = wl.astype(fnp.float32)
            cur = alive_idx[li]
            base = w32 if prev is None else fnp.take(w32, prev, axis=0)
            sliced.append(fnp.take(base, cur, axis=1))
            dprev = dead_idx[li - 1] if li > 0 else None
            if dprev is None:
                offsets.append(None)
            else:
                wd = fnp.take(fnp.take(w32, dprev, axis=0), cur, axis=1)
                offsets.append(fnp.take(mus[li - 1], dprev).astype(fnp.float32) @ wd)
            prev = cur

        rng = fnp.random.default_rng(mlp.seed)
        shift = rng.integers(0, 1 << _SOBOL_BITS, size=width, dtype=fnp.uint32)
        pts = self._base_points(n, width)

        # One shift + one quantile transform over the whole set: N = 16384 x 256
        # float32 is ~17 MB, far inside the 4 GiB single-array cap, so there is no
        # reason to chunk and every reason not to (each extra chunk repeats the
        # per-layer op sequence, and v2.2 measured residual scaling with chunks).
        u = (fnp.bitwise_xor(pts, shift).astype(fnp.float64) + 0.5) * (1.0 / float(1 << _SOBOL_BITS))
        h = flops.stats.norm.ppf(u).astype(fnp.float32)

        # Every width must be even for one Strassen level, including the sample
        # count and the unpruned input. If any layer is odd (a deformed or tiny
        # network), fall back to the dense chain -- exactly v2.4.1's behaviour.
        use_str = _STRASSEN and (n & 1) == 0 and all(
            (int(w.shape[0]) & 1) == 0 and (int(w.shape[1]) & 1) == 0 for w in sliced)
        if use_str:
            final = self._strassen_chain(h, sliced, offsets, depth, n)
        else:
            for li in range(depth):
                z = h @ sliced[li]
                if offsets[li] is not None:
                    z = z + offsets[li]
                h = fnp.maximum(z, fnp.float32(0.0))
            final = h.mean(axis=0, dtype=fnp.float64)
        rows = [mus[li] for li in range(depth)]
        rows[0] = self._exact_first_layer(w64[0])
        rows[depth - 1] = final
        return fnp.stack(rows, axis=0)

    # ------------------------------------------------------------------ #
    @staticmethod
    def _strassen_chain(h, sliced, offsets, depth, n):
        """One Strassen level per layer, block-resident, never concatenating.

        The seven right-hand sides depend only on the weights, so they are
        formed once per MLP per layer rather than once per sample batch.
        """
        m = n >> 1
        k = int(h.shape[1]) >> 1
        a11, a12 = h[:m, :k], h[:m, k:]
        a21, a22 = h[m:, :k], h[m:, k:]

        for li in range(depth):
            w = sliced[li]
            kh = int(w.shape[0]) >> 1
            nh = int(w.shape[1]) >> 1
            b11, b12 = w[:kh, :nh], w[:kh, nh:]
            b21, b22 = w[kh:, :nh], w[kh:, nh:]

            m1 = (a11 + a22) @ (b11 + b22)
            m2 = (a21 + a22) @ b11
            m3 = a11 @ (b12 - b22)
            m4 = a22 @ (b21 - b11)
            m5 = (a11 + a12) @ b22
            m6 = (a21 - a11) @ (b11 + b12)
            m7 = (a12 - a22) @ (b21 + b22)

            t11 = m1 + m4 - m5 + m7
            t12 = m3 + m5
            t21 = m2 + m4
            t22 = m1 - m2 + m3 + m6

            off = offsets[li]
            if off is not None:
                o1, o2 = off[:nh], off[nh:]
                t11 = t11 + o1
                t12 = t12 + o2
                t21 = t21 + o1
                t22 = t22 + o2

            z = fnp.float32(0.0)
            a11 = fnp.maximum(t11, z)
            a12 = fnp.maximum(t12, z)
            a21 = fnp.maximum(t21, z)
            a22 = fnp.maximum(t22, z)

        # Columns [0, nh) live in the left blocks, [nh, width) in the right.
        left = a11.sum(axis=0, dtype=fnp.float64) + a21.sum(axis=0, dtype=fnp.float64)
        right = a12.sum(axis=0, dtype=fnp.float64) + a22.sum(axis=0, dtype=fnp.float64)
        return fnp.concatenate([left, right]) * (1.0 / float(n))

    # ------------------------------------------------------------------ #
    @staticmethod
    def _base_points(n, width):
        """Unshifted Sobol integers for (n, width), cached across MLPs."""
        key = (n, width)
        cached = _BASE_POINTS.get(key)
        if cached is not None:
            return cached
        dirnum = _direction_numbers()
        idx = fnp.arange(n, dtype=fnp.uint32)
        idx = fnp.bitwise_xor(idx, fnp.right_shift(idx, fnp.uint32(1)))
        idx = idx.reshape((n, 1))
        pts = fnp.zeros((n, width), dtype=fnp.uint32)
        for k in range(_SOBOL_BITS):
            bit = fnp.bitwise_and(fnp.right_shift(idx, fnp.uint32(k)), fnp.uint32(1))
            pts = fnp.bitwise_xor(pts, bit * fnp.array(dirnum[k][:width], dtype=fnp.uint32))
        _BASE_POINTS[key] = pts
        return pts

    # ------------------------------------------------------------------ #
    def _closure(self, w64, width, depth):
        """Gaussian closure: per-layer firing index, post-ReLU mean, and Phi."""
        mu = fnp.zeros(width)
        cov = fnp.eye(width)
        off_mask = fnp.ones((width, width)) - fnp.eye(width)
        alphas, mus, phis = [], [], []
        for w in w64:
            mu_pre = w.T @ mu
            cov_pre = w.T @ cov @ w
            var_pre = fnp.maximum(fnp.diagonal(cov_pre), 1e-12)
            sig = fnp.sqrt(var_pre)
            alpha = mu_pre / sig
            Phi = flops.stats.norm.cdf(alpha)
            phi = flops.stats.norm.pdf(alpha)
            mu = mu_pre * Phi + sig * phi
            ez2 = (mu_pre * mu_pre + var_pre) * Phi + mu_pre * sig * phi
            var = fnp.maximum(ez2 - mu * mu, 0.0)
            cov = fnp.outer(Phi, Phi) * cov_pre * off_mask + fnp.diag(var)
            alphas.append(alpha)
            mus.append(mu)
            phis.append(Phi)
        return alphas, mus, phis

    # ------------------------------------------------------------------ #
    def _alignment_basis(self, w64, phis, width, depth):
        """Reproducible leading eigenvectors of J J^T for the linearised map.

        eigh on J J^T gives the same left singular vectors as an SVD of J for
        roughly a third of the price (measured 3.0e8 vs 8.7e8 FLOPs at n=256).
        Only the first `_BASIS_RANK` of them carry information (see the note
        there); the rest are numerical noise whose arbitrary orientation would
        otherwise make our realised error depend on the linear-algebra backend.
        So we keep the leading block, pin its column signs, and complete the
        basis with a complete-mode QR — deterministic given the leading block,
        and 2.0e6 FLOPs, i.e. 0.004% of budget and 150x cheaper than the eigh.
        """
        J = w64[0]
        for k in range(1, depth):
            J = (J * phis[k - 1]) @ w64[k]
        _, vecs = fnp.linalg.eigh(J @ J.T)
        k = _BASIS_RANK if _BASIS_RANK < width else width
        top = vecs[:, width - k :][:, ::-1]  # top-k, descending eigenvalue

        # Canonical sign: make each column's largest-magnitude entry positive,
        # using reductions only (no fancy indexing into a grader array).
        hi = fnp.max(top, axis=0)
        lo = fnp.min(top, axis=0)
        top = top * fnp.where(hi >= -lo, 1.0, -1.0)

        # For orthonormal input the R factor's leading k x k block is diagonal
        # with entries +/-1, so undoing those signs makes q[:, :k] reproduce
        # `top` exactly; q[:, k:] is then a deterministic completion.
        q, r = fnp.linalg.qr(top, mode="complete")
        d = fnp.diagonal(r)
        fix = fnp.concatenate([fnp.where(d < 0.0, -1.0, 1.0), fnp.ones(width - k)])
        return q * fix

    # ------------------------------------------------------------------ #
    def _slice_weights(self, weights, mus, alive_idx, width, depth):
        """Compress each layer to its surviving neurons, with the exact constant
        offset for everything dropped."""
        sliced, offsets = [], []
        prev = None
        for li in range(depth):
            w = weights[li]
            cur = alive_idx[li]
            wl = w if prev is None else fnp.take(w, prev, axis=0)
            sliced.append(fnp.take(wl, cur, axis=1))
            if prev is None or int(prev.shape[0]) == width:
                offsets.append(fnp.zeros(int(cur.shape[0]), dtype=fnp.float32))
            else:
                dead = self._complement(prev, width)
                if int(dead.shape[0]) == 0:
                    offsets.append(fnp.zeros(int(cur.shape[0]), dtype=fnp.float32))
                else:
                    wd = fnp.take(fnp.take(w, dead, axis=0), cur, axis=1)
                    md = fnp.take(mus[li - 1], dead)
                    offsets.append((md.astype(fnp.float64) @ wd.astype(fnp.float64)).astype(fnp.float32))
            prev = cur
        return sliced, offsets

    @staticmethod
    def _complement(idx, width):
        keep = fnp.zeros(width, dtype=fnp.uint32)
        keep = keep + 0  # keep grader arrays untouched
        mask = fnp.ones(width, dtype=fnp.uint32)
        mask = mask - fnp.bincount(idx.astype(fnp.int64), minlength=width).astype(fnp.uint32)
        return fnp.flatnonzero(mask)

    # ------------------------------------------------------------------ #
    def _log2_samples(self, width, depth, budget):
        if budget is None or budget <= 0:
            return -1
        per = _cost_per_sample(width, depth)
        if per <= 0:
            return -1
        target = _TARGET_CB * float(budget) / per
        hard = _MAX_CB * float(budget) / per
        log2n = _MIN_LOG2_N - 1
        for k in range(_MIN_LOG2_N, _MAX_LOG2_N + 1):
            if (1 << k) > hard:
                break
            log2n = k
            if (1 << k) >= target:
                break
        return log2n

    # ------------------------------------------------------------------ #
    def _exact_first_layer(self, w0):
        var = (w0 * w0).sum(axis=0, dtype=fnp.float64)
        return fnp.sqrt(var) * _INV_SQRT_2PI

    def _analytic_only(self, mlp, width, depth):
        w64 = [w.astype(fnp.float64) for w in mlp.weights]
        _, mus, _ = self._closure(w64, width, depth)
        rows = list(mus)
        rows[0] = self._exact_first_layer(w64[0])
        return fnp.stack(rows, axis=0)
