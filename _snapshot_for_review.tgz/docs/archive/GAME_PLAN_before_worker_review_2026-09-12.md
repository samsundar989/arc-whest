# GAME_PLAN.md — active Phase-2 implementation plan

**Revised September 10, 2026 after worker review at bcca354.** This is the sole active roadmap. Read [CURRENT_STATE](CURRENT_STATE.md), [WORKER_REVIEW](WORKER_REVIEW_2026-09-10.md), VALIDATION.md, GOTCHAS.md and LOG tail. The [prior plan](archive/GAME_PLAN_before_worker_review_2026-09-10.md) is historical. Existing gate verdicts, data restrictions and human approvals retain their scope.

**Execution status.** Stage 0 is implemented and independently accepted;
Stage 1's supplied-core algebra and compact counted-cost implementation have
scoped independent acceptance, while physical K4 source closure is reopened.
Stage 0's current positive plus M1--M12 certifier
battery passed under an enforced 8 GiB Linux cap and its final fresh Skeptic
returned ACCEPT; current default preflight passed 12/16 with the four Full-only
deployment steps explicitly skipped. Stage 1 has no server-residual evidence.
Their exact evidence and limitations are recorded in CURRENT_STATE and the LOG.
Stage 2 is the active frontier, but its old contract is superseded because P01 was
already exposed and its promised chronology cannot be reconstructed. Samuel's
replacement predictions are recorded as three verbatim `I don't know` answers;
the exact bounded P07 registry is committed and its pre-mint guard has independent
Skeptic acceptance. The standalone Stage-2 producer-receipt verifier passes 92/92
and has fresh Skeptic ACCEPT after repair of identity-role and same-byte-snapshot
defects. The compact four-arm implementation now passes its independent tiny dense
reference, current live-shape source/cost gates, official validation and a fresh
label-free Skeptic. Its ledgers are 816.293--818.516 billion FLOPs and the current
exact arm measured 1,079.0 MiB peak RAM. The registered P07 producer and verifier
completed; the exposed-DESIGN fit selected `lam=1/3`, and all four arms were
frozen. Job 957 subsequently completed the registered exposed-DESIGN four-arm
accuracy-only comparison: all K4 arms fail the arithmetic score gate. The fresh
result Skeptic accepted that measured failure but found the scientific cause
INCOMPLETE. A source-cumulant and covariance-symmetry defect needs a truth-free
discriminator before another label. The compact reference remains the priced
baseline for later residual/shared-coordinate questions. The subsequent
independent dense tensor oracle passes 49 checks with fresh scoped ACCEPT;
it proves selected linear contractions and a hidden residual, not nonlinear
closure. The Gaussian-pair post-ReLU integration passes 80 checks with fresh
scoped ACCEPT: at `rho=0.5`, mixed `K1122=0.10914008` changes fixed signed
future D4 substantially. Its metric-core projection needs a residual even
for independent inputs. Workerq 962 and 964 passed current live-byte default
preflight 12/16 each, four Full-only skips, with peaks 3,592.5 and 3,911.1
MiB. The subsequent full-sign n=2 weighted-cubature factor fixture passes
83 checks with fresh scoped Skeptic ACCEPT; workerq 971 passed live-byte
default preflight 12/16, four Full-only skips, at 3,720.9 MiB peak. It carries
the covariance subtraction and full residual through two signed maps, but
does not establish adequate factor rank at challenge width. LOG commit
`6a873ba` preregistered a four-coordinate source test: it passed 1088 checks
with fresh scoped Skeptic ACCEPT for the fixed first-layer Gaussian/ReLU
source (`K0123=0.01043695`; workerq 976/977 terminal, default preflight
12/16 with four Full-only skips). The separate low-rank feed/cost memo has a
fresh design-only Skeptic ACCEPT for its conditional algebra and conventional
ledger, but architecture INCOMPLETE: a later whole cumulant cannot be inserted
as an additive age source. The first two-layer increment fixture fails its
registered 32/48 convergence gate (300/323 pass); its independent Skeptic
REJECTED the combined numeric claim and accepted only same-discrete-measure
accounting. The boundary-aware repair failed its unchanged combined gate
(640/688); a distinct exact-axis three-node repair then passed 715/715 with
fresh Skeptic ACCEPT limited to a two-coordinate continuous law and toy linear
old carry (`increment_axis_gauss/`, `0782efa`). A separately accepted synthetic
one-first-source kernel measured 704.165 billion official-package FLOPs and
889.9 MiB process peak (`first_source_kernel/`, `70a2d80`); it omits physical
source generation, later increments and ordinary K3 backbone overlap. A
signed-feed embedding/rank fixture then passed 48/48 with fresh scoped
Skeptic ACCEPT (`feed_embedding/`, `dca4e7f`); its literal negative leg is
generically full rank, so rank384/residual16 remains unproved. The next
three-layer/two-source nonlinear old-history fixture (`39f21de`) failed
its combined gate 54/56 because the order48 bank misses final-D angular
boundaries; its independent Skeptic REJECTED the combined result and
accepted finite-bank algebra only. A separate abstract two-birth compact
feed fixture passed 74/74 with fresh scoped Skeptic ACCEPT at full n4
rank; rank2 loses materially (`two_birth_compact/`, `ad856c6`). Shared
workerq 994 default preflight passed 12/16, four Full-only skips, peak
2,842.9 MiB at exact tested bytes. The separately contracted full-polar
split-bank repair then passed 77/77, with 48/direct continuous third-layer
raw error `3.40e-15` and unchanged unsplit-bank negative control `3.14e-5`.
Its independent Skeptic ACCEPTED only the fixed two-coordinate numerical
repair and finite-bank conditional identities; workerq 996 default preflight
passed 12/16 at 2,946.8 MiB (`nonlinear_split_bank/`, `ec0bdf3`). Material
lower-moment leakage prevents a K4-only closure claim. LOG `ec0bdf3`
contracted an integrated one-first-source compact cost instrument. Its
frozen n4 oracle failed 93/172 from an unstable trajectory, and a separate
n8 oracle failed 186/187 from negative K4-corrected preactivation variance.
These are implementation/numerical FAILs, not a K4 scientific kill; no
width1024 meter was run. An exact positive S-column feed shortcut passed
789/789, cut counted tiny FLOPs 18.37%, and received fresh scoped Skeptic
ACCEPT without changing the n8 negative variance. A physical n2 signed-law
Gaussian-reset fixture passed 102/102 with fresh Skeptic ACCEPT only for
conditional cumulants and lower-moment leakage. Workerq 1009 controlled
live-byte default preflight passed 12/16, four Full-only skips, 346 Python
hashes unchanged. Full physical nonlinear source/compression, stable
covariance, complete counted cost, process peak and score remain open. The
self-contained `STRATEGIST_PACKET_2026-09-12.md` requests a priced causal
representation or explicit no-go before another fit or fresh decision.
The separate shape-only memory audit now has narrow fresh Skeptic ACCEPT
after two preserved INCOMPLETE ledger attempts: nine n8 boundaries pass
63/63, and a distinct n16/rank8/residual2 trace passes 93/93 with exact
retained-field shape/alias checks. Its n1024 **inclusive named-array
payload** is 715,844,864 bytes optimized versus 910,988,032 padded.
Workerq 1018/1019 controlled default preflights passed 12/16 with four
Full-only skips. The ledger does not bound helper/library workspaces or
whole-process RAM, and Windows did not enforce the grader's 8 GiB cap.
It is a planning instrument, not a priced stable integrated estimator;
do not launch the full-width meter until the causal source and covariance
gates pass. Exact raw paths and verdicts are at the LOG tail.
Stage 4 remains
conditional on a measured Stage-2 bottleneck.

## Objective and architecture

Aim at the fresh private rerun's best eligible submission, not a public-board fit. The inspected leader is about 6.8x better than our best public score, with undisclosed method and unavailable displayed truth-noise floor. **No winning architecture is established.** The current best-supported research direction is:

1. A reliable mean/full-covariance backbone conditioned on the actual weights.
2. Persistent K3 history, with exact recent sources and all older sources retained in common coordinates.
3. A cheap K4 core whose projection, transport, consumed slices and induced K3 births come from one explicitly defined representation.
4. Two shared dense legs plus an explicitly represented residual where the identity requires it; approximation of that residual is a separate intervention.
5. A weighted-Gram sketch/thin-QR join with a carried Gram core; nested older tiers only if the first tier earns them.
6. A final mean-only path and a small shape-generic immutable legal kernel, tested against the explicit research reference.

The [pinned public reconstruction](https://github.com/504aldo/whest-p2-cumulant-k3/tree/18c17e2d7a9aeacd399cfc2c6b571e4e16dbfb45) supplies external evidence, not a verified winning or eligible candidate. Distinguish exact reassociation from low-rank approximation, dropped terms, fitted constants and runtime choices. Do not copy public-fit coefficients or assume mutable-buffer legality. Keep the robust L2 fallback and frozen archives intact; no broad framework rewrite.

**Samuel has closed Stage 3: hold eligibility work off entirely.** Do not draft/send a new organizer question or advance a participant-derived reconstruction toward submission. Historical drafts are inactive. Attribution, fresh code or a mathematical rewrite alone does not resolve rules §6. Research can proceed within this hold.

## Stage 0 — instrument through its real paths (**implemented and accepted**)

**IMPORTANT:** write a prediction before each bounded instrument change, record evidence/knowledge delta, run required preflight and get a fresh-context Skeptic. Any change to gate policy, data tiers or residual model is STRATEGIC; do not smuggle it into a bug fix. No new research labels while repairing the measurement path.

| Package | Required completion evidence |
|---|---|
| 0A: verdicts and provenance | Production head/check tests correctly separate math, local runtime, server predictions and measured server evidence. Actual installed distribution versions bind producer/consumer. Instrument hashes have an explicit verified policy. Legacy missing fields yield INCOMPLETE; applicable explicit failures remain failures. Replay the new consumer on all seven stored reports without overwriting historical records. |
| 0B: lifecycle/memory | Stateless positive and retaining negative controls distinguish candidate memory from instrument-owned arrays over multiple MLPs. Release obsolete networks consistently. Do not require identical FLOPs across different networks unless the candidate contract warrants it. Fresh workload-bound Linux evidence enforces 8192 MiB; Windows accounting is labelled accounting. |
| 0C: executable lab/report | Parse every generated arm. Validate explicit arm list, control, configuration and non-overwriting output path before truth access. Writer accepts the actual dict schema and explicit configuration. Tiny synthetic end-to-end execution saves a complete report. No commands reference an unimplemented --fit. |
| 0D: noise/statistics | Integrate the helper into production reports; two-replica average uses the correct half-floor. Preserve MLP IDs, counted multipliers, failed-output handling, sample precision and observed/corrected/official-precision comparisons. Test unequal multipliers end to end. Label build, kill and mechanism outcomes separately; competition_score.decide(gate=...) remains sole promotion authority. Fix or explicitly bound extreme-alpha inversion. |
| 0E: truth/provenance | Route protected consumers, including p2_corrector.py, through pre-read reservation. Audit bypasses. Preserve P08 exhaustion and P01 exposure. Use automatic run receipts and distinguish historical supplied timestamps from measured execution time. No backdating or resets. |
| 0F: future vault safety | Preserve Phase-1 seal/refusal. On sacrificial fixtures, prove atomic pre-read cap reservation, crash accounting and concurrent exclusion before any future Phase-2 enablement. Do not create/read a Phase-2 vault merely to repair this path. |

Passing helper suites is insufficient: reproduce the review counterexamples at the real entry points, then show they discriminate the repair. Keep valid earlier fixes. Do not retroactively change a historical gate or claim its result reversed without a separately supported decision.

Inspect in-flight jobs first. Default preflight **574** was submitted with no source snapshot and remained queued; attribute its eventual result to actual executing bytes or replace this owned job with a frozen run. It is not Full. Locate the worker's separate full mutation result; avoid duplicate substantial runs. Required heavy preflight, full mutation, live-shape memory/evaluation jobs go through workerq with RAM/VRAM/CPU declarations. No priority changes or queue bypass.

## Stage 1 — intended representation and executable cost (**supplied-core baseline accepted; physical closure open**)

**IMPORTANT probe mathematics, without protected labels.** The worker's 28 tiny identity checks survive; its complete-closure and cost conclusions do not. Use independently derived dense fixtures rather than mirroring implementation formulas.

### 1A: coherent core conformance

Write down the represented tensor/polynomial, orientations, metric factors and harmonic projection. Derive transport, D4, D22, D31 and every induced K3 feed/birth together. Check signed/nonconstant and zero cores, repeated indices, permutations, cancellation and zero-variance limits against a tiny dense oracle. The matrix-core diagonal identity is only one part of this proof.

Emit **exact / coherent / consumers-only / births-only**, with independently verified consumer and feed switches. No-carry is not no-birth. Parse all generated code. Verify zero-core nesting and exact-control outputs and counted cost; a printed cost mismatch must fail. Do not repair the coefficient mismatch by fitting theta around it.

### 1B: shared coordinates and complete costs

Derive transport, insertion, weighted Gram sketch, thin QR, factor rotation, carried Gram update, contraction and readout for all retained generations. Compare with the exact-old-source reference. Preserve and name residual terms omitted by SIMPLE; two-leg reassociation is not a claim that full AUGMENT/K4 is free.

Price the **same algorithm that runs**. Include two shared dense legs, residuals, all source factors, Gram operations, QR, rebasing, reconstruction, casts, materialisation, calls and peak scratch memory. Match initial and final-layer shortcuts in both control and intervention. The (r+n) eigendecomposition ledger is a historical hypothetical, not a published-configuration estimate, feasibility bound or reason to reject the architecture. A scalar calibration does not repair mismatched algorithms.

Start with tiny metered operation-family checks; then queue label-free 1024 x 16 execution to verify counts, legal primitives and lifecycle. Record exact raw ledgers before quoting exact FLOPs. The local official-package ledger and grading-server offset remain distinct. Residual is headroom against a cliff, not a Phase-2 cost term.

**Stage-1 exit:** independent conformance passes; executable end-to-end report works; complete counted costs are reproducible; remaining approximations are named; fresh Skeptic accepts the evidence. If conformance fails, repair the implementation rather than kill the scientific hypothesis. If a correctly implemented full program is uncompetitive, synthesize before spending labels.

## Stage 2 — valid design, then fresh decisions

**September 12 execution state.** The label-free producer (workerq 903),
standalone verifier, registered protected P07 DESIGN fit and four-arm freeze
completed. The selected registered coefficient is `lam=1/3`; the four candidates
had identical counted costs per identity. This fit is DESIGN only. The accepted
metadata-import repair at `ab969c8` was necessary after two P01 attempts failed
before arm scoring; workerq 948 passed live-byte default preflight 12/16 (four
Full-only skips), a fresh Skeptic accepted the scoped repair, and a fresh freeze
receipt now binds the repaired bootstrap while all four arm bytes remain exactly
unchanged. Workerq **949** failed after scoring the exact control on all 96
exposed P01 DESIGN networks, before depth analysis or publication. Its peak
was 1,543.9 MiB against an 8 GiB queue reservation. The bounded depth-loader
and origin-audit repair is preregistered in the LOG; truth-free real-entry
evidence, current-byte preflight and a fresh Skeptic must precede the next
P01 attempt. Workerq 950 passed current-byte default preflight 12/16 (four
Full-only skips), but an independent Skeptic rejected the final publication
gate: a copied truth-free lab can leave a complete report after the outer
bootstrap refuses an unregistered late module. The LOG now contracts a
publication-transaction repair and a new preflight/Skeptic gate before any
P01 retry. Its first implementation `fa9a4d8` passed workerq 952 default
preflight 12/16, but a separate sacrificial direct-bootstrap call supplied
its own stage and left a `complete` stage after final refusal. The new LOG-tail
contract requires a pending stage until successful parent publication; no
independent acceptance existed at that historical point. The final held
receipt-lock repair `bb81abf` passed workerq 956 current-byte default
preflight 12/16 (four Full-only skips) and a new fresh Skeptic **ACCEPTED**
the scoped publication instrument. The registered P01 comparison subsequently
ran on exposed DESIGN data with an accuracy-only residual-cap relaxation;
its terminal report, result Skeptic and synthesis are recorded below. P01 had five
documented reads before job 949 (three historical smoke reads and two failed
production attempts), and job 949 added one more; it remains exposed DESIGN.
The earlier paragraphs below describe the entry contract and historical queue state.

**Terminal P01 update and synthesis.** Workerq 957 published the complete four-arm report
over 96 exposed-DESIGN identities with no failed lifecycle rows and about
3,792.4 MiB peak process RAM. All three K4 arms fail the registered arithmetic
1.10x gate and are worse on every paired case; the consumer-bearing arms are
numerically extreme. The independent result Skeptic's verdict is **INCOMPLETE
for causal K4** but accepts the failed promotion gate for the frozen program.
The source constructs a central moment rather than a fourth cumulant, fabricates
mixed fourth cumulants on independent coordinates, and applies a generally
asymmetric D31 covariance term. The earlier dense oracle did not check this
source construction. LOG commits `c54eb87` and `2164401` record synthesis,
a truth-free analytic fixture, live-byte preflight and a fresh Skeptic
**ACCEPT** for the scoped source-identity defect. The fixture's synthetic
width-1024 frozen D4 is about 1150 times the direct independent cumulant;
that is an algebra error on an atypical network, not a measured P01 effect.
That check now passed 14/14, with fresh Skeptic ACCEPT for the scoped
executable source identity (commits `a419e55`, `040b472`, `95c70b8`;
workerq 961 default preflight 12/16, four Full-only skips). The separate
repair-math Skeptic accepted the proposed tensor algebra but marked the
architecture INCOMPLETE: present repeated-index slices do not carry an
all-distinct residual through future dense transport. The dense linear oracle
and correlated Gaussian-pair source now each have narrow fresh Skeptic
ACCEPT; their artifacts are under `source_dense/` and `mixed_source/`.
The latter's metric-core residual remains material. The full-sign weighted
cubature factor and n=4 first-layer source checks now have narrow fresh
Skeptic ACCEPT. A later whole cumulant is not an additive increment; the
first two-layer convergence gate failed while its finite-measure algebra
passed. The boundary-aware attempt also failed its combined convergence gate;
the exact-axis repair passed with narrow independent acceptance. The first
nonlinear old-history bank failed continuous integration; a separate
split-bank toy repair passed narrowly. Full-rank abstract compact multi-birth
feed integration passed narrowly,
but physical source closure and compressed integration remain open
before any corrected full arm. Do not fit a new constant or spend
another protected label until the source math is independently checked and
repaired within a new contract and fresh Skeptic gate. This is not a registered
scientific kill of the intended representation.
The residual-cap relaxation means this run supplies no 0.4 s server-cliff
evidence. Defer the residual-rank slice until the first mechanism is sound.

**Current entry condition satisfied:** the replacement experiment contract, three
verbatim `I don't know` human predictions and bounded coefficient/identity registry
are committed in the LOG. The label-free producer guard has fresh-context Skeptic
acceptance. Current-source preflight and the standalone producer-receipt verifier
are accepted. The compact four-arm implementation, complete live-shape ledgers and
memory accounting also have fresh-context label-free ACCEPT. The downstream
freeze/P01 bridge now has current-byte default preflight and fresh-context ACCEPT
after fail-closed import/source-binding repairs. The label-free P07 producer,
verification and registered protected P07 fit completed. The later metadata and
depth-loader issues are described in the September 12 execution state above.
Do not reuse the predictions attached to the rejected placeholder
implementation.

The current 08f787b contract has **not been tested as specified**. It promised a freeze before P01, but P01 has three recorded DESIGN reads and informed the proposed range. Manual timestamps cannot establish preregistration chronology. Preserve exposure; reconcile independent job records if available; otherwise mark chronology unresolved. Do not recycle the old contract/predictions as evidence for a changed intervention.

Before any new measurement, transparently amend/supersede the affected contract in LOG. State CONFIRMED/INFERRED/SPECULATIVE evidence, one mechanism, intervention, predictions, falsifier, exact controls, counted-cost model, residual headroom policy, truth precision, paired arithmetic statistic, explicit isolated gate and data role. Obtain Samuel's predictions when required and commit before touching the block. Do not guess his answers; continue independent engineering while waiting.

P01 can only be treated honestly as already exposed DESIGN. P07 may support authorized design fitting, with all exposure disclosed. Neither becomes untouched DECIDE by relabeling. Allocate genuinely fresh decision blocks through the ledger when their registered role requires them. No public fitting; public CONFIRM remains read-only. No vault authorization is implied.

| Order | Scientific question | Required discriminator |
|---:|---|---|
| 1 | Does the coherent K4 core improve the trusted chain? | Correct four-arm mechanism comparison; valid common-random-number pairing and separately registered build/kill/mechanism rules. |
| 2 | Can the residual be thin without losing useful feedback? | Dense residual, identical term set; rank loss separated from term deletion. |
| 3 | Do shared old-source coordinates improve total score? | All ages retained; exact-old-source control and a matched random-basis control; price all joins and contractions. |
| 4 | Does a nested older tier add useful savings? | Frozen first-tier baseline and full reconstruction/update costs. |
| 5 | Does the frozen combined candidate generalize? | Fresh untouched DECIDE, binding arithmetic gate/Skeptic, then read-only public CONFIRM if authorized under the protocol. |

Implement a reproducible fitting interface only after core conformance, with bounded registered design choices, immutable fit receipts and frozen outputs. No autonomous optimization loop. The failed placeholder smoke is neither a coherent-core kill nor a basis for an unregistered fit-range claim. One strategic result must end with synthesis and Skeptic before the next implementation.

## Stage 3 — held by Samuel

Participant-derived reconstruction remains attributed research. Do not seek clarification, prepare a submission or claim eligibility under this plan. Candidate-neutral instrument/reference work can continue. Preserve estimator.py, frozen archives and #330566. If Samuel later reopens this stage, first document eligibility/provenance, then validate exact legal bytes, compare every consumed slice to the reference, obtain candidate-specific runtime/memory evidence and a clean official mini. Submission still needs per-submission approval; no agent designates. This paragraph is conditional guidance, not authorization.

## Stage 4 — bounded frontier extension after the baseline

Choose one from the measured compact-baseline bottleneck; neither is already a demonstrated improvement.

| Priority | Hypothesis and evidence | First falsifier before labels |
|---|---|---|
| A | Sketch quadratic old-source products before dense reconstruction; polynomial TensorSketch literature motivates the representation. | Derive rolling transport/join and protected contractions, signed-tensor variance and full supported-primitive cost. Stop if dense replay or replicas erase savings. |
| B | Select the shared basis for downstream output error, rather than factor energy alone; goal-oriented reduction motivates the objective. | Equal-cost perturbation/oracle evidence must show lower necessary rank after counting sensitivity construction. Reversing unchanged contractions does not qualify. |

Stochastic residual tails and relational in-flight K4 correction remain secondary hypotheses requiring conditional-bias/variance or reachable-state evidence. No broad training before a feasible representation and a useful target. Do not reopen scalar final-readout fitting, generation caps or primary sampling without new external evidence and a distinct contract. [Primary literature, limitations and falsifiers](research/2026-09-10_literature_review.md).

## Completion and handoff

Complete authorized engineering, validation and evidence before asking for a decision that truly requires Samuel. When a human prediction or the Stage-3 hold blocks dependent work, continue independent unblocked packages. Queue waits are not completion; failed build gates are not kills; historical green checks do not certify new bytes. Do not force a positive result to satisfy a completion prompt.

Every package ends with exact raw artifact paths, source hashes, knowledge delta, tests with scope/skips, remaining risks and a fresh-context Skeptic. Update this plan/CURRENT_STATE coherently, with append-only LOG history. Keep contribution write-up stale until its claims earn review. Aim for a validated research baseline promptly and leave runtime/verification reserve before October 17, 23:59 UTC; queue capacity and scientific outcomes determine the actual schedule. When evidence is exhausted, deliver a self-contained Strategist Packet rather than inventing another sweep.

Copy-ready execution instructions: [CODEX_EXECUTION_HANDOFF](CODEX_EXECUTION_HANDOFF.md).
