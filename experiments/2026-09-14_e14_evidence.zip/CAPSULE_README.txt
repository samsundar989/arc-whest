E14 exact-byte evidence. Read experiments/2026-09-14_e14/README.md first.
CAPSULE_MANIFEST.json hashes every preserved input file. Verify members directly
with Python zipfile and hashlib. Sources are the exact live bytes checked by
preflight, which can differ from normalized Git checkout bytes. Original
absolute paths in raw receipts are preserved for provenance; they are not
rewritten claims about another execution location. The F21 candidate tarball
is reused unchanged. No truth access, experiment resumption, submission,
designation or waiver is authorized by this capsule.
