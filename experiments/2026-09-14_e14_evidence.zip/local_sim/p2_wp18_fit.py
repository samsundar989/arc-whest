"""WP18 / Arm L, step B2: the `E3` map. Ridge, leave-networks-out, `G-L-FIT-E3`.

Contract: `experiments/LOG.md`, 2026-09-03, "CONTRACT WP18" § B, committed at
`49e2e42`. Gate `G-L-FIT-E3`: held-out `R^2` on `E3` **`>= 0.90`**,
layer-averaged over pre-layers `5..15` (the `l + 1` of gate layers `4..14`),
leave-networks-out on `P05`, with the per-layer minimum reported beside it.

**Every fitting choice below was written before any label existed** -- this file
is committed alongside the label job, not after reading its output. That is the
whole point, and the choices are listed here so a reader can check they were not
adjusted to the answer.

THE FIVE CHOICES, DECLARED
--------------------------
1. **`R^2` is UNCENTERED, against zero**: `1 - ||E3 - E3_hat||^2 / ||E3||^2`.
   That is exactly `gm_depth.json`'s `explained`, and it is the right convention
   here because a deployed map must produce the *value*, not the deviation from
   a mean it would have to be told. A centered `R^2` is reported beside it for
   reference and scores no gate.
2. **ONE coefficient vector across all pre-layers**, not one per layer. `CONTRACT
   WP15` caps the basis at 50 coefficients total; eleven per-layer vectors over
   25 features would be 275. The features carry the layer's own scale (they are
   built from its actual state), so a single fixed vector is the deployable
   object -- and it makes the per-layer table a real test rather than eleven
   independent fits.
3. **Per-block weighting `1 / ||E3||^2`.** Pooled least squares would be
   dominated by whichever pre-layer has the largest `||E3||`, and the gate is
   layer-averaged. Weighting each `(net, pre-layer)` block by the inverse of its
   own energy makes the pooled objective the mean of per-block `1 - explained`,
   which is the quantity the gate is written on.
4. **Column scaling by training-fold RMS**, never by held-out data. Absorbed
   into the coefficients at deploy time, so it costs no operations and adds no
   constants to the 50.
5. **The ridge penalty is chosen by an INNER leave-networks-out split on the
   training folds only.** The outer held-out fold is never consulted for it.
   This is the discipline WP13's selector lane lost first.

THE NULL DIFFERS IN CODE PATH
-----------------------------
`--null permute-coefficients` fits normally and then permutes the coefficient
vector across basis terms before prediction. Same arithmetic, same cost, same
magnitudes, wrong assignment. `eps = 0` is a determinism check and is not a
null; `CONTRACT WP15` is explicit and both Skeptics were.

WHAT IS NOT HERE
----------------
The `E21` leg. Its target is `n x n` and a dense store is `4.6 GB`, so the fit
consumes a Gram/moment reduction (`<T_t, T_s>`, `<T_t, E21>`, `||E21||^2`) that
`p2_wp18_labels.py` computes in a SECOND pass once the `E21` basis is declared.
Declaring the basis and then computing its moments cannot be reversed into a
basis chosen after seeing the target, which is why the order is that way round.

Run (CPU, light -- the labels are already reduced to n-vectors):
    uv run python local_sim/p2_wp18_fit.py --labels experiments/2026-09-03_wp18_armL/labels_P05.npz
    uv run python local_sim/p2_wp18_fit.py --labels <npz> --null permute-coefficients
"""

from __future__ import annotations

import argparse
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != _HERE] + [_ROOT, _HERE]

import numpy as np  # noqa: E402

#: `G-L-FIT-E3`, fixed in `CONTRACT WP18` § B before any label existed.
G_L_FIT_E3 = 0.90

#: The ridge ladder the inner split chooses from. A ladder, not a continuous
#: search, so the choice is reproducible and reportable.
LAMBDAS = (0.0, 1e-12, 1e-10, 1e-8, 1e-6, 1e-4, 1e-2, 1.0)

#: Outer folds for leave-networks-out. 8 folds of 16 networks at `n_nets = 128`.
N_FOLDS = 8


def _blocks(FEAT, E3):
    """Flatten `(nets, layers, n, feat)` into per-`(net, layer)` blocks.

    Returns a list of `(net_index, layer_index, X, y)` with `X` shaped
    `(n, n_feat)` and `y` shaped `(n,)`. Keeping the block structure is what
    makes the per-block weighting and the per-layer report possible.
    """
    out = []
    for i in range(FEAT.shape[0]):
        for j in range(FEAT.shape[1]):
            out.append((i, j, FEAT[i, j], E3[i, j]))
    return out


def _weighted_normal_equations(blocks, idx, scale):
    """`(X^T W X, X^T W y, sum_w ||y||^2)` over the blocks named by `idx`.

    `W` is `1 / ||y||^2` per block -- declared choice 3. A block with
    `||y|| == 0` carries no information about the map and is dropped rather than
    given infinite weight; the count of dropped blocks is returned so it can
    never be silent.
    """
    n_feat = blocks[0][2].shape[1]
    G = np.zeros((n_feat, n_feat), dtype=np.float64)
    b = np.zeros(n_feat, dtype=np.float64)
    sst = 0.0
    dropped = 0
    for k in idx:
        _i, _j, X, y = blocks[k]
        e = float(y @ y)
        if not (e > 0.0) or not np.isfinite(e):
            dropped += 1
            continue
        w = 1.0 / e
        Xs = X / scale
        G += w * (Xs.T @ Xs)
        b += w * (Xs.T @ y)
        sst += w * e
    return G, b, sst, dropped


def _solve(G, b, lam):
    n = G.shape[0]
    tr = float(np.trace(G)) / max(n, 1)
    return np.linalg.solve(G + lam * tr * np.eye(n), b)


def _score(blocks, idx, coef, scale):
    """Per-block uncentered and centered `R^2`. No weighting: a score, not a fit."""
    rows = []
    for k in idx:
        i, j, X, y = blocks[k]
        yhat = (X / scale) @ coef
        e = float(y @ y)
        r = y - yhat
        sse = float(r @ r)
        yc = y - y.mean()
        sst_c = float(yc @ yc)
        rows.append({
            "net": int(i), "layer_index": int(j),
            "r2_uncentered": 1.0 - sse / max(e, 1e-300),
            "r2_centered": 1.0 - sse / max(sst_c, 1e-300),
            "norm_y": float(np.sqrt(e)),
        })
    return rows


def cmd_fit(a) -> int:
    z = np.load(a.labels, allow_pickle=False)
    FEAT, E3 = z["FEAT"], z["E3"]
    names = [str(x) for x in z["feature_names"]]
    pre = [int(x) for x in z["pre_layers"]]
    n_nets, n_lay, n_neur, n_feat = FEAT.shape
    ep = bool(z["endpoint_pass"][0]) if "endpoint_pass" in z else None
    print(f"  labels    {os.path.relpath(a.labels, _ROOT)}")
    print(f"  shape     {n_nets} nets x {n_lay} pre-layers {pre[0]}..{pre[-1]} "
          f"x {n_neur} neurons x {n_feat} features")
    print(f"  B1 endpoint check in the label file: "
          f"{'PASS' if ep else ('FAIL' if ep is False else 'absent')}")
    if ep is False:
        print("  REFUSED: the labeller's own endpoint check FAILED, so these "
              "labels are not E3. CONTRACT WP18 B1 stops the slice here.")
        return 1

    blocks = _blocks(FEAT, E3)
    all_idx = list(range(len(blocks)))
    # Column scale from the WHOLE set is forbidden -- choice 4. It is computed
    # per outer fold from the training blocks only, inside the loop.
    folds = [[k for k in all_idx if (blocks[k][0] % N_FOLDS) == f]
             for f in range(N_FOLDS)]

    held, chosen = [], []
    for f in range(N_FOLDS):
        te = folds[f]
        tr = [k for k in all_idx if k not in set(te)]
        Xtr = np.concatenate([blocks[k][2] for k in tr], axis=0)
        scale = np.sqrt((Xtr * Xtr).mean(axis=0))
        scale = np.where(scale > 0, scale, 1.0)

        # --- inner leave-networks-out on the TRAINING folds only, for lambda
        inner_nets = sorted({blocks[k][0] for k in tr})
        inner_hold = set(inner_nets[::N_FOLDS])
        itr = [k for k in tr if blocks[k][0] not in inner_hold]
        ite = [k for k in tr if blocks[k][0] in inner_hold]
        Gi, bi, _s, _d = _weighted_normal_equations(blocks, itr, scale)
        best, best_lam = -np.inf, LAMBDAS[0]
        for lam in LAMBDAS:
            try:
                c = _solve(Gi, bi, lam)
            except np.linalg.LinAlgError:
                continue
            m = float(np.mean([r["r2_uncentered"]
                               for r in _score(blocks, ite, c, scale)]))
            if m > best:
                best, best_lam = m, lam
        chosen.append({"fold": f, "lambda": best_lam, "inner_r2": best})

        G, b, _s, dropped = _weighted_normal_equations(blocks, tr, scale)
        coef = _solve(G, b, best_lam)
        if a.null == "permute-coefficients":
            # CODE-PATH-DISTINCT NULL: same arithmetic, same magnitudes, wrong
            # assignment. Seeded off the fold so it is reproducible.
            rng = np.random.default_rng(20260903 + f)
            coef = coef[rng.permutation(coef.size)]
        rows = _score(blocks, te, coef, scale)
        for r in rows:
            r["fold"] = f
        held.extend(rows)
        print(f"    fold {f}  lambda {best_lam:.0e}  dropped {dropped}  "
              f"held-out mean R^2 (uncentered) "
              f"{np.mean([r['r2_uncentered'] for r in rows]):+.4f}")

    # ---- the gate: layer-averaged held-out R^2, per-layer minimum beside it --
    per_layer = []
    for j, p in enumerate(pre):
        v = [r["r2_uncentered"] for r in held if r["layer_index"] == j]
        vc = [r["r2_centered"] for r in held if r["layer_index"] == j]
        per_layer.append({"pre_layer": p, "n": len(v),
                          "r2_uncentered_mean": float(np.mean(v)),
                          "r2_uncentered_min": float(np.min(v)),
                          "r2_centered_mean": float(np.mean(vc))})
    lay_avg = float(np.mean([r["r2_uncentered_mean"] for r in per_layer]))
    lay_min = float(np.min([r["r2_uncentered_mean"] for r in per_layer]))
    passed = bool(lay_avg >= G_L_FIT_E3)

    print()
    print("  held-out R^2 on E3, leave-networks-out, uncentered")
    print(f"    {'pre-layer':>10}{'mean':>10}{'worst net':>12}{'centered':>11}")
    for r in per_layer:
        print(f"    {r['pre_layer']:>10}{r['r2_uncentered_mean']:>10.4f}"
              f"{r['r2_uncentered_min']:>12.4f}{r['r2_centered_mean']:>11.4f}")
    print()
    print(f"  G-L-FIT-E3: layer-averaged {lay_avg:.4f} vs {G_L_FIT_E3:.2f}"
          f"   {'PASS' if passed else 'FAIL'}"
          + ("   [NULL RUN -- this is not a result]" if a.null else ""))
    print(f"  worst pre-layer mean {lay_min:.4f}")

    # ---- the coefficients, by name, on a full-data refit (REPORT ONLY) ------
    Xall = np.concatenate([blocks[k][2] for k in all_idx], axis=0)
    sc = np.sqrt((Xall * Xall).mean(axis=0))
    sc = np.where(sc > 0, sc, 1.0)
    G, b, _s, _d = _weighted_normal_equations(blocks, all_idx, sc)
    lam_mode = max(set(c["lambda"] for c in chosen),
                   key=lambda L: sum(1 for c in chosen if c["lambda"] == L))
    full = _solve(G, b, lam_mode)
    order = np.argsort(-np.abs(full))
    print()
    print(f"  full-data refit at the modal lambda {lam_mode:.0e} "
          f"-- REPORT ONLY, scores no gate. Coefficients by |size|:")
    for k in order[: min(10, full.size)]:
        print(f"    {names[k]:<16}{full[k]:+.6e}")

    if a.out:
        _dump(a.out, {
            "check": "WP18 Arm L step B2: the E3 map, ridge, leave-networks-out",
            "contract": "experiments/LOG.md 2026-09-03 CONTRACT WP18 § B, "
                        "HEAD 49e2e42",
            "labels": os.path.relpath(a.labels, _ROOT),
            "gate": "G-L-FIT-E3", "threshold": G_L_FIT_E3,
            "null": a.null or "none",
            "n_nets": int(n_nets), "pre_layers": pre,
            "feature_names": names, "n_folds": N_FOLDS,
            "lambda_ladder": list(LAMBDAS), "fold_lambdas": chosen,
            "per_layer": per_layer,
            "layer_averaged_r2": lay_avg, "worst_layer_r2": lay_min,
            "pass": passed,
            "full_refit_lambda": lam_mode,
            "full_refit_coefficients": {names[i]: float(full[i])
                                        for i in range(full.size)},
            "caveat": "DESIGN tier on P05, where CONTRACT WP18 permits tuning. "
                      "G-L-FIT is a FIT gate, not an outcome gate: the outcome "
                      "gate is G-L-E2E, in flight, on P06[..064..127].",
        })
    return 0 if passed else 1


def cmd_diagnose(a) -> int:
    """WHY the pooled fit failed. DIAGNOSTIC ONLY -- it scores no gate.

    `G-L-FIT-E3` is written on ONE coefficient vector across all pre-layers,
    because that is the deployable object and because eleven per-layer vectors
    over 24 features would be 264 coefficients against a cap of 50. It failed at
    `0.1002`. There are two very different worlds behind that number and the gate
    cannot tell them apart:

      * the features do not explain `E3` at all -- in which case the cheap leg of
        Arm L is dead and no amount of per-layer freedom helps; or
      * they explain it well *within* a layer, and a single fixed vector cannot
        span the layers' different regimes -- in which case a handful of
        layer-dependent scalars would fit inside the coefficient cap and the
        gate failed for a reason that is fixable.

    Three ceilings, each strictly above the last, all held out where that is
    meaningful:

      `pooled`      the gate itself, reproduced here for comparison.
      `per-layer`   one coefficient vector PER pre-layer, still leave-networks-out.
                    Not deployable as-is; an upper bound on what layer-dependent
                    scaling could buy.
      `per-block`   one vector fitted ON each `(net, layer)` block and scored on
                    THAT SAME block. **In-sample by construction, so it is not a
                    result** -- it is the ceiling of the 24-column basis itself.
                    If this is low, nothing built from these features can work,
                    and that is the finding.
    """
    z = np.load(a.labels, allow_pickle=False)
    FEAT, E3 = z["FEAT"], z["E3"]
    pre = [int(x) for x in z["pre_layers"]]
    names = [str(x) for x in z["feature_names"]]
    blocks = _blocks(FEAT, E3)
    all_idx = list(range(len(blocks)))
    n_lay = FEAT.shape[1]

    print("  DIAGNOSTIC ONLY. G-L-FIT-E3 is written on the pooled fit and it")
    print("  FAILED; nothing here changes that. This asks WHY.")
    print()
    print(f"    {'pre-layer':>10}{'per-layer LNO':>16}{'per-block ceiling':>20}")
    rows = []
    for j in range(n_lay):
        idx = [k for k in all_idx if blocks[k][1] == j]
        # --- per-layer, leave-networks-out
        held = []
        for f in range(N_FOLDS):
            te = [k for k in idx if (blocks[k][0] % N_FOLDS) == f]
            tr = [k for k in idx if (blocks[k][0] % N_FOLDS) != f]
            Xtr = np.concatenate([blocks[k][2] for k in tr], axis=0)
            sc = np.sqrt((Xtr * Xtr).mean(axis=0))
            sc = np.where(sc > 0, sc, 1.0)
            G, b, _s, _d = _weighted_normal_equations(blocks, tr, sc)
            c = _solve(G, b, 1e-8)
            held += [r["r2_uncentered"] for r in _score(blocks, te, c, sc)]
        # --- per-block ceiling, IN SAMPLE by construction
        ceil = []
        for k in idx:
            _i, _j, X, y = blocks[k]
            sc = np.sqrt((X * X).mean(axis=0))
            sc = np.where(sc > 0, sc, 1.0)
            Xs = X / sc
            c, *_ = np.linalg.lstsq(Xs, y, rcond=None)
            r = y - Xs @ c
            ceil.append(1.0 - float(r @ r) / max(float(y @ y), 1e-300))
        rows.append({"pre_layer": pre[j],
                     "per_layer_lno": float(np.mean(held)),
                     "per_block_ceiling_in_sample": float(np.mean(ceil))})
        print(f"    {pre[j]:>10}{np.mean(held):>16.4f}{np.mean(ceil):>20.4f}")

    pl = float(np.mean([r["per_layer_lno"] for r in rows]))
    pb = float(np.mean([r["per_block_ceiling_in_sample"] for r in rows]))
    print()
    print(f"    per-layer LNO, layer-averaged          {pl:.4f}")
    print(f"    per-block ceiling (IN SAMPLE, not a result) {pb:.4f}")
    print()
    if pb < 0.5:
        print("    -> THE BASIS IS THE PROBLEM, not the pooling. Even fitted ON")
        print("       the block it is scored on, these 24 features explain less")
        print("       than half of E3. Layer-dependent scalars cannot rescue a")
        print("       ceiling; the feature set is missing the mechanism.")
    elif pl < 0.5 <= pb:
        print("    -> TRANSFER is the problem: the basis can fit a block it has")
        print("       seen and cannot predict a network it has not.")
    else:
        print("    -> POOLING is the problem: within a layer the map transfers,")
        print("       and a layer-independent coefficient vector cannot span the")
        print("       layers. Layer-dependent scalars would fit inside the cap.")
    if a.out:
        _dump(a.out, {"check": "WP18 Arm L: WHY the pooled E3 fit failed",
                      "note": "DIAGNOSTIC ONLY -- scores no gate. G-L-FIT-E3 is "
                              "the pooled fit and it FAILED at 0.1002.",
                      "labels": os.path.relpath(a.labels, _ROOT),
                      "feature_names": names, "per_layer": rows,
                      "per_layer_lno_mean": pl,
                      "per_block_ceiling_in_sample_mean": pb})
    return 0


# ==========================================================================
# --e21: the matrix leg, from the Gram/moment reduction
# ==========================================================================

#: `G-L-FIT-E21`, fixed in `CONTRACT WP18` § B before any moment existed.
G_L_FIT_E21 = 0.90


def _e21_r2(Y, b, G, c):
    """Exact uncentered `R^2` from the reduction. No dense `E21` is needed.

    For a basis linear in its coefficients the residual is exactly
    `||E21||^2 - 2 c.b + c^T G c`, so `R^2 = 1 - that / ||E21||^2` is closed
    form -- which is why the labeller stores `(G, b, ||E21||^2)` and not a
    `4.6 GB` target.
    """
    return 1.0 - (Y - 2.0 * float(c @ b) + float(c @ (G @ c))) / max(Y, 1e-300)


def _e21_ceiling(Y, b, G, rcond=1e-10):
    """The in-sample ceiling of the basis on ONE block: `b^T G^+ b / ||E21||^2`.

    The least-squares optimum over the whole basis, fitted on the block it is
    scored on. It is not a result -- it is the most any map built from these 29
    terms could achieve there. `SKEPTIC WP18-B` showed on the `E3` leg that this
    number is worth more than the gate, because a low ceiling closes a route
    where a low held-out score only means "fit it better".
    """
    return float(b @ np.linalg.pinv(G, rcond=rcond) @ b) / max(Y, 1e-300)


def _e21_solve(G, b, lam):
    n = G.shape[0]
    tr = float(np.trace(G)) / max(n, 1)
    return np.linalg.solve(G + lam * max(tr, 1e-300) * np.eye(n), b)


def cmd_e21(a) -> int:
    z = np.load(a.e21, allow_pickle=False)
    G, B, Y = z["GRAM"], z["MOM"], z["E21_SQ"]
    names = [str(x) for x in z["term_names"]]
    mm = {str(x) for x in z["matmul_terms"]}
    pre = [int(x) for x in z["pre_layers"]]
    n_nets, n_lay, nt, _ = G.shape
    print(f"  moments   {os.path.relpath(a.e21, _ROOT)}")
    print(f"  shape     {n_nets} nets x {n_lay} pre-layers {pre[0]}..{pre[-1]}"
          f" x {nt} frozen basis terms ({len(mm)} matmul-class)")

    idx = [(i, j) for i in range(n_nets) for j in range(n_lay)]

    def fit(train, cols, lam):
        w = np.array([1.0 / max(Y[i, j], 1e-300) for (i, j) in train])
        Gs = sum(wi * G[i, j][np.ix_(cols, cols)]
                 for wi, (i, j) in zip(w, train))
        bs = sum(wi * B[i, j][cols] for wi, (i, j) in zip(w, train))
        d = np.sqrt(np.maximum(np.diag(Gs), 0.0))
        d = np.where(d > 0, d, 1.0)
        c = _e21_solve(Gs / np.outer(d, d), bs / d, lam)
        return c / d

    def score(blocks, cols, c):
        return [_e21_r2(Y[i, j], B[i, j][cols], G[i, j][np.ix_(cols, cols)], c)
                for (i, j) in blocks]

    all_cols = list(range(nt))
    folds = [[k for k in idx if (k[0] % N_FOLDS) == f] for f in range(N_FOLDS)]

    def run(cols, label):
        held, chosen = [], []
        for f in range(N_FOLDS):
            te = folds[f]
            tr = [k for k in idx if (k[0] % N_FOLDS) != f]
            inner_hold = set(sorted({k[0] for k in tr})[::N_FOLDS])
            itr = [k for k in tr if k[0] not in inner_hold]
            ite = [k for k in tr if k[0] in inner_hold]
            best, best_lam = -np.inf, LAMBDAS[0]
            for lam in LAMBDAS:
                try:
                    ci = fit(itr, cols, lam)
                except np.linalg.LinAlgError:
                    continue
                m = float(np.mean(score(ite, cols, ci)))
                if m > best:
                    best, best_lam = m, lam
            c = fit(tr, cols, best_lam)
            if a.null == "permute-coefficients":
                rng = np.random.default_rng(20260903 + f)
                c = c[rng.permutation(c.size)]
            chosen.append({"fold": f, "lambda": best_lam})
            for k, r2 in zip(te, score(te, cols, c)):
                held.append({"net": k[0], "layer_index": k[1], "r2": r2, "fold": f})
        per_layer = []
        for j, pl in enumerate(pre):
            v = [h["r2"] for h in held if h["layer_index"] == j]
            per_layer.append({"pre_layer": pl, "r2_mean": float(np.mean(v)),
                              "r2_min": float(np.min(v))})
        lay = float(np.mean([r["r2_mean"] for r in per_layer]))
        print(f"    {label:<34} layer-averaged held-out R^2 {lay:+.4f}")
        return lay, per_layer, chosen

    print()
    print("  held-out R^2 on E21, leave-networks-out")
    full_lay, full_pl, chosen = run(all_cols, "ALL 29 terms")

    # G-L-COST: at most ONE matmul-class term is deployable.
    non_mm = [i for i, n in enumerate(names) if n not in mm]
    best_one, best_name, best_pl = None, None, None
    lay_nomm, pl_nomm, _ = run(non_mm, "Hadamard/diagonal only (0 matmuls)")
    for i, n in enumerate(names):
        if n not in mm:
            continue
        lay_i, pl_i, _ = run(non_mm + [i], f"  + one matmul term: {n}")
        if best_one is None or lay_i > best_one:
            best_one, best_name, best_pl = lay_i, n, pl_i

    print()
    print(f"    {'pre-layer':>10}{'R^2 mean':>11}{'worst net':>12}")
    for r in best_pl:
        print(f"    {r['pre_layer']:>10}{r['r2_mean']:>11.4f}{r['r2_min']:>12.4f}")

    # the ceiling, exact and nearly free from the reduction
    ceil = {}
    for j in range(n_lay):
        v = [_e21_ceiling(Y[i, j], B[i, j], G[i, j]) for i in range(n_nets)]
        ceil[pre[j]] = float(np.mean(v))
    ceil_mean = float(np.mean(list(ceil.values())))

    passed = bool(best_one is not None and best_one >= G_L_FIT_E21)
    print()
    print(f"  DEPLOYABLE fit (Hadamard/diagonal + at most ONE matmul term, "
          f"the best being {best_name})")
    print(f"  G-L-FIT-E21: layer-averaged {best_one:.4f} vs {G_L_FIT_E21:.2f}"
          f"   {'PASS' if passed else 'FAIL'}"
          + ("   [NULL RUN -- not a result]" if a.null else ""))
    print(f"  unrestricted (all 29, NOT deployable): {full_lay:.4f}")
    print(f"  IN-SAMPLE CEILING of the 29-term basis: {ceil_mean:.4f}"
          f"   (per layer {min(ceil.values()):.4f}..{max(ceil.values()):.4f})")
    if ceil_mean < 0.5:
        print("    -> THE BASIS IS THE LIMIT, not the fit. Fitted ON the block")
        print("       it is scored on, these terms cannot reach the gate.")

    if a.out:
        _dump(a.out, {
            "check": "WP18 Arm L: the E21 map, ridge on the Gram/moment "
                     "reduction, leave-networks-out",
            "contract": "experiments/LOG.md CONTRACT WP18 § B; basis frozen "
                        "before moments (CONTRACT WP19 commit)",
            "moments": os.path.relpath(a.e21, _ROOT),
            "gate": "G-L-FIT-E21", "threshold": G_L_FIT_E21,
            "null": a.null or "none",
            "n_nets": int(n_nets), "pre_layers": pre, "term_names": names,
            "matmul_terms": sorted(mm), "n_folds": N_FOLDS,
            "deployable_best_matmul_term": best_name,
            "deployable_layer_averaged_r2": best_one,
            "deployable_per_layer": best_pl,
            "no_matmul_layer_averaged_r2": lay_nomm,
            "unrestricted_all_terms_r2": full_lay,
            "in_sample_ceiling_mean": ceil_mean,
            "in_sample_ceiling_per_layer": ceil,
            "fold_lambdas": chosen, "pass": passed,
            "caveat": "DESIGN tier on P05. G-L-FIT is a FIT gate; the outcome "
                      "gate is G-L-E2E, in flight, on P06[..064..127]. Terms "
                      "marked matmul-class cost 2 n^3 a layer each and at most "
                      "ONE fits inside G-L-COST.",
        })
    return 0 if passed else 1


def _dump(path, doc):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=1)
    print(f"  wrote {os.path.relpath(path, _ROOT)}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels")
    ap.add_argument("--e21", help="the Gram/moment npz for the E21 leg")
    ap.add_argument("--null", choices=("permute-coefficients",), default=None)
    ap.add_argument("--diagnose", action="store_true")
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    print("=" * 78)
    print("WP18 / Arm L  --  the fitted maps, and G-L-FIT")
    print("=" * 78)
    if a.e21:
        return cmd_e21(a)
    if not a.labels:
        ap.error("one of --labels / --e21")
    if a.diagnose:
        return cmd_diagnose(a)
    return cmd_fit(a)


if __name__ == "__main__":
    raise SystemExit(main())
